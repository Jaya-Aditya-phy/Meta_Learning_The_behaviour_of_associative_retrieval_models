"""
LAYER 2b -- USING THE UNCERTAINTY TO FIX THE MODEL (diagnose, then correct)
============================================================================
Layer 2 found the accuracy-optimal setting is overconfident and Layer 1 showed
accuracy and calibration pull apart along n_eff. Layer 2b asks: can the biases the
uncertainty reveals be corrected, honestly, and how does retrieval compare with the
density-weighted kNN baseline on IDENTICAL nested folds?

Models (all: outer LOEGO, settings chosen by an inner GroupKFold on outer-train batches)
    retrieval_acc   : Layer 0 retrieval, (k, beta) by inner accuracy
    retrieval_cal   : Layer 0 retrieval, (k, beta) by inner calibration (NLL)
    knn             : plain uniform kNN (retrieval with beta ~ 0), k by inner accuracy
    density_log     : density-weighted kNN (weights = local density / distance, soft
                      correlation feature weights -- the a density-weighted kNN baseline
                      predictor), k in (1,3,5,7,9) by inner LOG-space MSE, predictions
                      averaged in LOG space -> same metric/space as the retrieval rows
    density_native  : the same predictor scored the way a density-weighted kNN baseline scores
                      itself: k by inner RAW-space R^2, predictions averaged in RAW space,
                      then log10 for the reported R^2. Reproduces the baseline's number
                      (up to unsteered/no-glycerol-input) and isolates the metric effect.

Corrections (fitted on INNER out-of-fold predictions only):
    sigma       : one inflation factor on the interval width
    bias        : y ~ a + b * prediction
    bias+sigma  : both
(applied to every model except density_native, whose point predictions are reported raw)

Also reports PAIRED batch-bootstrap CIs for R^2 differences between models.

Run:
    neffretrieval recalibrate --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm
from sklearn.metrics import pairwise_distances, r2_score
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.preprocessing import StandardScaler

from . import bridge as L1
from . import nested as L2

BETA_GRID, K_GRID = L1.BETA_GRID, L1.K_GRID
CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
KNN_BETA = 1e-6                      # ~uniform weights over the k nearest => plain kNN
DENS_K = (1, 3, 5, 7, 9)             # same k grid as a density-weighted kNN baseline
INNER_SPLITS = 5
MODELS = ["retrieval_acc", "retrieval_cal", "knn", "density_log", "density_native"]
VARIANTS = ["raw", "sigma", "bias", "bias+sigma"]
OUT_DIR = "outputs/recalibration"
RET_CFGS = [(k, b) for k in K_GRID for b in BETA_GRID]
KNN_CFGS = [(k, KNN_BETA) for k in K_GRID]
DENS_CFGS = [("dens", k) for k in DENS_K]


# ----------------------------------------------------------------------------
# density-weighted kNN (mirrors a density-weighted kNN baseline)
# ----------------------------------------------------------------------------
def _local_density_copy(X, k=9):
    D = pairwise_distances(X, X, metric="euclidean")
    np.fill_diagonal(D, np.inf)
    kk = min(k, max(1, X.shape[0] - 1))
    knn_d = np.partition(D, kk - 1, axis=1)[:, :kk]
    return 1.0 / np.maximum(np.mean(knn_d, axis=1), 1e-12)


def _corr_weights_copy(Z, y2):
    """Soft |corr| feature weights vs concentration (column 1), mean-normalised to 1."""
    yv = y2[:, 1]
    w = np.zeros(Z.shape[1])
    for j in range(Z.shape[1]):
        x = Z[:, j]
        if np.std(x) < 1e-12 or np.std(yv) < 1e-12:
            continue
        c = np.corrcoef(x, yv)[0, 1]
        w[j] = 0.0 if np.isnan(c) else abs(c)
    mw = w.mean()
    return np.ones_like(w) if mw < 1e-12 else w / mw


def make_density_helpers(base=None):
    """Use the real functions from an external baseline module when available."""
    if base is not None:
        corr_fn = lambda Z, y2: base.compute_correlation_weights(Z, y2, base.TARGETS, "concentration_wv")
        dens_fn = base._local_density
    else:
        corr_fn, dens_fn = _corr_weights_copy, _local_density_copy
    return corr_fn, dens_fn


class DensityKNN:
    """Per-fold: median impute -> z-score (train only) -> soft correlation weights (train only)
    -> density-weighted top-k. Returns log-space mean/spread/weights AND the raw-space
    mean (what a density-weighted kNN baseline averages)."""

    def __init__(self, corr_fn, dens_fn):
        self.corr_fn, self.dens_fn = corr_fn, dens_fn

    def fit(self, X, y_log):
        X = np.asarray(X, float)
        self.med_ = np.nanmedian(X, axis=0)
        self.med_ = np.where(np.isnan(self.med_), 0.0, self.med_)
        X = np.where(np.isnan(X), self.med_, X)
        self.scaler_ = StandardScaler().fit(X)
        Z = self.scaler_.transform(X)
        self.yraw_ = 10.0 ** np.asarray(y_log, float)
        self.w_ = self.corr_fn(Z, np.c_[np.zeros(len(Z)), self.yraw_])   # [glycerol placeholder, conc]
        self.Z_ = Z * self.w_
        self.y_ = np.asarray(y_log, float)
        return self

    def predict(self, Xq, k):
        Xq = np.where(np.isnan(np.asarray(Xq, float)), self.med_, Xq)
        Zq = self.scaler_.transform(Xq) * self.w_
        k = min(k, len(self.Z_))
        D = pairwise_distances(Zq, self.Z_, metric="euclidean")
        idx = np.argpartition(D, kth=k - 1, axis=1)[:, :k]
        d = np.take_along_axis(D, idx, axis=1)
        rho = self.dens_fn(self.Z_, k)[idx]
        w = rho / np.maximum(d, 1e-12)
        w = w / np.maximum(w.sum(axis=1, keepdims=True), 1e-12)
        yl = self.y_[idx]
        mu = (w * yl).sum(axis=1)
        sd = np.sqrt(np.maximum((w * (yl - mu[:, None]) ** 2).sum(axis=1), 0.0))
        raw = (w * self.yraw_[idx]).sum(axis=1)
        return mu, sd, w, np.log10(np.clip(raw, 1e-9, None)), raw


# ----------------------------------------------------------------------------
# inner loop: out-of-fold predictions for every config, outer-train batches only
# ----------------------------------------------------------------------------
def inner_oof(Xtr, ytr, gtr, Model, corr, floor_frac, dens_factory, n_splits=INNER_SPLITS):
    cfgs = RET_CFGS + KNN_CFGS + DENS_CFGS
    store = {c: dict(y=[], mu=[], sd=[], ne=[]) for c in cfgs}
    native = {k: [] for k in DENS_K}
    gkf = GroupKFold(n_splits=min(n_splits, len(np.unique(gtr))))
    for itr, ite in gkf.split(Xtr, ytr, gtr):
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(Xtr[itr], ytr[itr])
        floor = floor_frac * np.std(ytr[itr])
        for (k, b) in RET_CFGS + KNN_CFGS:
            m.beta, m.k = b, k
            mu, sd, W = m.predict(Xtr[ite])
            s = store[(k, b)]
            s["y"].append(ytr[ite]); s["mu"].append(mu)
            s["sd"].append(np.maximum(sd, floor)); s["ne"].append(L1.n_eff_from_weights(W))
        dm = dens_factory().fit(Xtr[itr], ytr[itr])
        for k in DENS_K:
            mu, sd, W, _, raw = dm.predict(Xtr[ite], k)
            s = store[("dens", k)]
            s["y"].append(ytr[ite]); s["mu"].append(mu)
            s["sd"].append(np.maximum(sd, floor)); s["ne"].append(L1.n_eff_from_weights(W))
            native[k].append(r2_score(10.0 ** ytr[ite], raw))
    oof, sc = {}, {}
    for c, s in store.items():
        y, mu, sd, ne = (np.concatenate(s[key]) for key in ("y", "mu", "sd", "ne"))
        oof[c] = (y, mu, sd)
        e2 = (mu - y) ** 2
        sc[c] = dict(mse=e2.mean(), se=e2.std(ddof=1) / np.sqrt(len(e2)),
                     nll=np.mean(-norm.logpdf(mu - y, scale=sd)), mse_raw=np.nan, n_eff=ne.mean())
    native_score = {k: float(np.nanmean(v)) for k, v in native.items()}
    return oof, sc, native_score


def pick(model, sc, native_score=None):
    if model == "retrieval_acc":
        return L2.select("accuracy", {c: sc[c] for c in RET_CFGS})
    if model == "retrieval_cal":
        return L2.select("calibration", {c: sc[c] for c in RET_CFGS})
    if model == "knn":
        return L2.select("accuracy", {c: sc[c] for c in KNN_CFGS})
    if model == "density_log":
        return L2.select("accuracy", {c: sc[c] for c in DENS_CFGS})
    if model == "density_native":
        return ("dens", max(native_score, key=native_score.get))
    raise ValueError(model)


# ----------------------------------------------------------------------------
# corrections (fitted on inner OOF predictions of the chosen config)
# ----------------------------------------------------------------------------
def fit_corrections(y, mu, sd):
    if np.std(mu) > 1e-9:
        slope, icpt = np.polyfit(mu, y, 1)
    else:
        slope, icpt = 1.0, 0.0
    s_raw = float(np.clip(np.sqrt(np.mean(((mu - y) / sd) ** 2)), 0.5, 5.0))
    mu_b = icpt + slope * mu
    s_bias = float(np.clip(np.sqrt(np.mean(((mu_b - y) / sd) ** 2)), 0.5, 5.0))
    return dict(slope=slope, icpt=icpt, s_raw=s_raw, s_bias=s_bias)


def apply_variants(mu, sd, c):
    mu_b = c["icpt"] + c["slope"] * mu
    return {"raw": (mu, sd), "sigma": (mu, sd * c["s_raw"]),
            "bias": (mu_b, sd), "bias+sigma": (mu_b, sd * c["s_bias"])}


# ----------------------------------------------------------------------------
# outer loop
# ----------------------------------------------------------------------------
def run(X, y, groups, Model, dens_factory, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
        inner=INNER_SPLITS):
    n = len(y)
    out = {m: {v: dict(mu=np.zeros(n), sd=np.zeros(n)) for v in VARIANTS} for m in MODELS}
    ne_out = {m: np.zeros(n) for m in MODELS}
    cfg_rows = []
    for fold, (tr, te) in enumerate(LeaveOneGroupOut().split(X, y, groups)):
        oof, sc, native_score = inner_oof(X[tr], y[tr], groups[tr], Model, corr, floor_frac,
                                          dens_factory, inner)
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X[tr], y[tr])
        dm = dens_factory().fit(X[tr], y[tr])
        floor = floor_frac * np.std(y[tr])
        for model in MODELS:
            cfg = pick(model, sc, native_score)
            if cfg[0] == "dens":
                mu, sd, W, mu_nat, _ = dm.predict(X[te], cfg[1])
                if model == "density_native":
                    mu = mu_nat                         # raw-space average, then log10
            else:
                m.beta, m.k = cfg[1], cfg[0]
                mu, sd, W = m.predict(X[te])
            sd = np.maximum(sd, floor)
            if model == "density_native":
                c = dict(slope=1.0, icpt=0.0, s_raw=1.0, s_bias=1.0)
            else:
                c = fit_corrections(*oof[cfg])
            for v, (mu_v, sd_v) in apply_variants(mu, sd, c).items():
                out[model][v]["mu"][te], out[model][v]["sd"][te] = mu_v, sd_v
            ne_out[model][te] = L1.n_eff_from_weights(W)
            kk = cfg[1] if cfg[0] == "dens" else cfg[0]
            bb = np.nan if cfg[0] == "dens" else cfg[1]
            cfg_rows.append(dict(fold=fold, model=model, k=kk, beta=bb, slope=c["slope"],
                                 icpt=c["icpt"], s_raw=c["s_raw"], s_bias=c["s_bias"]))
    return out, ne_out, pd.DataFrame(cfg_rows)


# ----------------------------------------------------------------------------
# diagnostics, tables, paired comparisons
# ----------------------------------------------------------------------------
def slope_ci(y, mu, g, n_boot=500, seed=0):
    rng = np.random.default_rng(seed)
    ug = np.unique(g)
    idx = {u: np.where(g == u)[0] for u in ug}
    vals = []
    for _ in range(n_boot):
        ii = np.concatenate([idx[u] for u in rng.choice(ug, len(ug))])
        vals.append(np.polyfit(mu[ii], y[ii], 1)[0])
    return np.percentile(vals, [2.5, 97.5])


def paired_r2_diff(y, mu_a, mu_b, g, n_boot=1000, seed=0):
    """R2(a) - R2(b) with a 95% CI from resampling whole batches (same resample for both)."""
    rng = np.random.default_rng(seed)
    ug = np.unique(g)
    idx = {u: np.where(g == u)[0] for u in ug}
    d = []
    for _ in range(n_boot):
        ii = np.concatenate([idx[u] for u in rng.choice(ug, len(ug))])
        d.append(L2.r2(y[ii], mu_a[ii]) - L2.r2(y[ii], mu_b[ii]))
    return L2.r2(y, mu_a) - L2.r2(y, mu_b), np.percentile(d, [2.5, 97.5])


def diagnostics(name, y, mu, sd, ne, groups):
    e = mu - y
    z = e / sd
    slope, icpt = np.polyfit(mu, y, 1)
    lo, hi = slope_ci(y, mu, groups)
    print(f"\n--- DIAGNOSTICS: {name} (held-out LOEGO predictions, raw) ---")
    print(f"calibration-in-the-large: y = {icpt:+.3f} + {slope:.3f} * prediction   "
          f"slope 95% CI [{lo:.3f}, {hi:.3f}]   (CI containing 1 = no demonstrable shrinkage bias)")
    print(f"z-scores: mean z^2 = {np.mean(z ** 2):.2f} (ideal 1.0), cov68 = {np.mean(np.abs(z) <= 1):.2f}, "
          f"cov95 = {np.mean(np.abs(z) <= 1.96):.2f}")
    q = np.quantile(ne, [0.25, 0.5, 0.75])
    nb = np.digitize(ne, q)
    print("coverage by n_eff quartile (low n_eff = few voters):")
    for i in range(4):
        mk = nb == i
        print(f"   Q{i + 1}: mean n_eff {ne[mk].mean():5.1f}  cov68 {np.mean(np.abs(z[mk]) <= 1):.2f}"
              f"  cov95 {np.mean(np.abs(z[mk]) <= 1.96):.2f}  mean z^2 {np.mean(z[mk] ** 2):.2f}  n={mk.sum()}")
    return dict(slope=slope, icpt=icpt, e=e, z=z, y=y)


def table(out, y, groups):
    rows = []
    for model in MODELS:
        for v in (["raw"] if model == "density_native" else VARIANTS):
            mu, sd = out[model][v]["mu"], out[model][v]["sd"]
            mt = L2.metrics(y, mu, sd)
            lo, hi = L2.group_bootstrap_r2(y, mu, groups)
            rows.append(dict(model=model, variant=v, r2=mt["r2"], r2_lo=lo, r2_hi=hi, mae=mt["mae"],
                             cov68=mt["cov68"], cov95=mt["cov95"], nll=mt["nll"]))
    return pd.DataFrame(rows)


def make_figure(d, tab, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.8), constrained_layout=True)
    ax[0].scatter(d["y"], d["e"], s=10, alpha=0.6)
    ax[0].axhline(0, color="k", lw=0.8)
    ax[0].set_xlabel("true log10 concentration"); ax[0].set_ylabel("prediction - truth")
    ax[0].set_title("Error vs truth (retrieval, accuracy policy)")
    ax[1].hist(d["z"], bins=30, density=True, alpha=0.7, label="z = error / sigma")
    g = np.linspace(-5, 5, 200)
    ax[1].plot(g, norm.pdf(g), "k--", label="N(0,1) if calibrated")
    ax[1].set_xlim(-6, 6); ax[1].set_xlabel("z"); ax[1].set_title("Is the stated uncertainty the right size?")
    ax[1].legend()
    sub = tab[tab.model == "retrieval_acc"]
    x = np.arange(len(sub))
    ax[2].bar(x - 0.2, sub["cov95"], 0.4, label="cov95 (ideal 0.95)")
    ax[2].bar(x + 0.2, sub["cov68"], 0.4, label="cov68 (ideal 0.68)")
    ax[2].axhline(0.95, color="C0", ls=":"); ax[2].axhline(0.68, color="C1", ls=":")
    ax[2].set_xticks(x, sub["variant"]); ax[2].set_ylim(0, 1.05)
    ax[2].set_title("Coverage after each correction (retrieval, accuracy policy)"); ax[2].legend(fontsize=8)
    fig.savefig(f"{out_dir}/fig7_recalibration.png", dpi=160, bbox_inches="tight"); plt.close(fig)


def analyse(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            inner=INNER_SPLITS, out_dir=OUT_DIR, base=None):
    groups = np.asarray(groups)
    corr_fn, dens_fn = make_density_helpers(base)
    dens_factory = lambda: DensityKNN(corr_fn, dens_fn)
    print(f"\nLayer 2b data: X={X.shape}, groups={len(set(groups))}, inner folds={inner}, "
          f"density helpers from {'an external baseline module' if base is not None else 'local copies'}")
    print("Running nested LOEGO (5 models; 4 correction variants each except density_native) ...")
    out, ne_out, cfg = run(X, y, groups, Model, dens_factory, corr, floor_frac, inner)
    os.makedirs(out_dir, exist_ok=True)
    cfg.to_csv(f"{out_dir}/fitted_corrections.csv", index=False)

    d = diagnostics("retrieval, accuracy policy", y, out["retrieval_acc"]["raw"]["mu"],
                    out["retrieval_acc"]["raw"]["sd"], ne_out["retrieval_acc"], groups)
    tab = table(out, y, groups)
    tab.to_csv(f"{out_dir}/recalibration_results.csv", index=False)
    pd.set_option("display.width", 200)
    print("\n=== OUTER (LOEGO) SCORES, log10 concentration (same folds for every model) ===")
    print(tab.round(3).to_string(index=False))

    print("\n=== PAIRED R2 DIFFERENCES (95% CI by resampling batches; CI containing 0 = no resolvable gap) ===")
    pairs = [("retrieval_acc", "raw", "density_native", "raw"),
             ("retrieval_acc", "raw", "density_log", "raw"),
             ("retrieval_cal", "raw", "density_log", "raw"),
             ("retrieval_cal", "bias", "density_log", "bias"),
             ("density_log", "raw", "density_native", "raw"),
             ("retrieval_acc", "raw", "knn", "raw")]
    for a, va, b, vb in pairs:
        diff, (lo, hi) = paired_r2_diff(y, out[a][va]["mu"], out[b][vb]["mu"], groups)
        print(f"   {a}[{va}] - {b}[{vb}]: {diff:+.3f}   CI [{lo:+.3f}, {hi:+.3f}]")

    print("\n=== FITTED CORRECTIONS (per outer fold; stable = trustworthy) ===")
    g = cfg[cfg.model != "density_native"].groupby("model")[["slope", "icpt", "s_raw", "s_bias"]] \
        .agg(["median", "min", "max"]).round(2)
    print(g.to_string())
    print("\n=== WHAT EACH MODEL CHOSE (median k, per outer fold) ===")
    print(cfg.groupby("model")["k"].agg(["median", "min", "max"]).to_string())

    def get(m, v, col):
        return tab[(tab.model == m) & (tab.variant == v)][col].item()
    print("\n=== DID THE CORRECTIONS IMPROVE R2? ===")
    for m in MODELS:
        if m == "density_native":
            continue
        print(f"{m}: R2 raw {get(m, 'raw', 'r2'):.3f} -> bias {get(m, 'bias', 'r2'):.3f}   "
              f"cov95 raw {get(m, 'raw', 'cov95'):.2f} -> sigma {get(m, 'sigma', 'cov95'):.2f}   "
              f"cov68 raw {get(m, 'raw', 'cov68'):.2f} -> sigma {get(m, 'sigma', 'cov68'):.2f}")
    make_figure(d, tab, out_dir)
    print(f"\nSaved tables + figure in ./{out_dir}/")
    return out, tab, cfg
