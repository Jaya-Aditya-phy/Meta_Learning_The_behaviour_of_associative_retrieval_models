"""Command-line interface:  neffretrieval <command> [options]

Commands (each is one analysis layer):
  demo                run the bridge + nested analyses on a synthetic dataset (no data needed)
  bridge              n_eff as a bridge variable: accuracy, calibration and entropy vs n_eff
  nested              honest accuracy: nested cross-validation selection policies
  recalibrate         where the uncertainty fails; bias and sigma corrections; baselines
  scaling             how n_eff and the best sharpness depend on training size
  correction-scaling  how the corrections depend on training size
  neff-policy         search a target n_eff instead of a (k, beta) grid
  landscape           density / energy landscape maps of the fitted model
  grounding           do model behaviours track physical variables?

Data: pass --csv with one row per sample, or omit it to use the synthetic benchmark.
"""
import argparse
import sys

from . import __version__
from .data import load_csv, make_synthetic
from .retrieval import AssociativeRetrieval


def _common(p):
    g = p.add_argument_group("data")
    g.add_argument("--csv", help="CSV with one row per sample (omit to use the synthetic benchmark)")
    g.add_argument("--target", default="y", help="target column (default: y)")
    g.add_argument("--group", default="batch", help="grouping column such as batch/subject/site (default: batch)")
    g.add_argument("--features", default=None, help="comma-separated feature columns (default: all numeric)")
    g.add_argument("--log10-target", action="store_true", help="take log10 of the target (must be positive)")
    g.add_argument("--seed", type=int, default=0, help="seed for the synthetic benchmark")
    m = p.add_argument_group("model")
    m.add_argument("--corr", type=lambda s: None if s.lower() == "none" else float(s), default=0.4,
                   help="drop features with |corr| below this on training rows (use 'none' to keep all)")
    m.add_argument("--floor", type=float, default=0.05, help="uncertainty floor as a fraction of label spread")
    p.add_argument("--out", default=None, help="output directory (default: outputs/<command>)")


def _load(a):
    if a.csv:
        feats = a.features.split(",") if a.features else None
        X, y, g, _, frame = load_csv(a.csv, a.target, a.group, feats, a.log10_target)
        return X, y, g, frame
    X, y, g = make_synthetic(seed=a.seed)
    return X, y, g, None


def build_parser():
    ap = argparse.ArgumentParser(prog="neffretrieval", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ["demo", "bridge", "nested", "recalibrate", "scaling", "correction-scaling",
                 "neff-policy", "landscape", "grounding"]:
        p = sub.add_parser(name, help=name)
        _common(p)
        if name in ("scaling", "correction-scaling"):
            p.add_argument("--reps", type=int, default=None, help="random subsample draws per training size")
        if name == "scaling":
            p.add_argument("--boot", type=int, default=300, help="bootstrap resamples")
        if name in ("nested", "recalibrate", "correction-scaling", "neff-policy"):
            p.add_argument("--inner", type=int, default=5, help="inner GroupKFold splits")
        if name in ("correction-scaling", "grounding"):
            p.add_argument("--acc-k", type=int, default=9); p.add_argument("--acc-beta", type=float, default=2.0)
            p.add_argument("--cal-k", type=int, default=100); p.add_argument("--cal-beta", type=float, default=1.0)
        if name == "correction-scaling":
            p.add_argument("--knn-k", type=int, default=5); p.add_argument("--dens-k", type=int, default=5)
        if name == "grounding":
            p.add_argument("--physics-cols", default=None, help="comma-separated numeric physical-variable columns in the CSV")
            p.add_argument("--category-col", default=None, help="optional categorical column to test (e.g. material)")
    return ap


def main(argv=None):
    a = build_parser().parse_args(argv)
    X, y, g, frame = _load(a)
    M = AssociativeRetrieval
    kw = {} if a.out is None else {"out_dir": a.out}
    if a.cmd == "demo":
        from . import bridge, nested
        sub = (lambda s: {"out_dir": f"{a.out}/{s}"}) if a.out else (lambda s: {})
        bridge.analyse(X, y, g, M, a.corr, a.floor, **sub("bridge"))
        nested.analyse(X, y, g, M, a.corr, a.floor, 5, **sub("nested"))
    elif a.cmd == "bridge":
        from . import bridge
        bridge.analyse(X, y, g, M, a.corr, a.floor, **kw)
    elif a.cmd == "nested":
        from . import nested
        nested.analyse(X, y, g, M, a.corr, a.floor, a.inner, **kw)
    elif a.cmd == "recalibrate":
        from . import recalibration
        recalibration.analyse(X, y, g, M, a.corr, a.floor, a.inner, **kw)
    elif a.cmd == "scaling":
        from . import scaling
        scaling.analyse(X, y, g, M, a.corr, a.floor, reps=a.reps or scaling.REPS, n_boot=a.boot, **kw)
    elif a.cmd == "correction-scaling":
        from . import correction_scaling as cs
        specs = cs.default_specs(a.acc_k, a.acc_beta, a.cal_k, a.cal_beta, a.knn_k, a.dens_k)
        cs.analyse(X, y, g, M, specs, a.corr, a.floor, reps=a.reps or cs.REPS, inner=a.inner, **kw)
    elif a.cmd == "neff-policy":
        from . import neff_policy
        neff_policy.analyse(X, y, g, M, a.corr, a.floor, a.inner, **kw)
    elif a.cmd == "landscape":
        from . import landscape
        landscape.analyse(X, y, M, a.corr, **kw)
    elif a.cmd == "grounding":
        from . import grounding
        if frame is None or not a.physics_cols:
            sys.exit("grounding needs --csv and --physics-cols (comma-separated numeric columns of the CSV)")
        phys = grounding.build_physics_generic(frame, a.group, a.physics_cols.split(","), a.category_col,
                                               target=y, target_name=a.target)
        grounding.analyse(X, y, g, M, phys, a.corr, a.floor, (a.acc_k, a.acc_beta), (a.cal_k, a.cal_beta), **kw)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
