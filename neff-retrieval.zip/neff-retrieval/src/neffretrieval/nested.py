"""
LAYER 2 -- THE SELECTION POLICY (nested cross-validation as meta-learning)
===========================================================================
Layer 1 showed the model's behaviour is organised by n_eff, which is set by the
two internal controls (k, beta). Layer 2 asks: how should those controls be
CHOSEN, honestly?

The object being learned here is not a prediction, it is a SELECTION POLICY:
a rule  (training data)  ->  (k, beta).  Each policy is scored only on data it
never saw while choosing:

    outer loop : leave-one-experimental-group-out (LOEGO)       <- reported score
        inner loop : GroupKFold on the outer-TRAIN groups only   <- picks (k, beta)

Policies compared (same grid as Layer 1, same Layer 0 model):
    accuracy      : minimise inner MSE (log10 conc)
    accuracy_1se  : among configs within 1 SE of the best inner MSE, take the one
                    with the LARGEST n_eff (more averaging, usually better calibrated)
    calibration   : minimise inner Gaussian NLL
    legacy_raw    : minimise inner MSE in RAW concentration space while the outer
                    score is in log space  -- the scoring mismatch bug, kept as an
                    explicit "before" so the fix has a measured effect

Reference rows
    global_mean   : predict the training mean (floor to beat)
    best_of_grid  : best fixed config picked by the OUTER score itself. This is the
                    optimistic number (selection leaks into the report). The gap
                    best_of_grid - nested accuracy is the SELECTION OPTIMISM.

Run:
    neffretrieval nested --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut

from . import bridge as L1          # same grid, same n_eff definition

BETA_GRID, K_GRID = L1.BETA_GRID, L1.K_GRID
CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
INNER_SPLITS = 5
POLICIES = ["accuracy", "accuracy_1se", "calibration", "legacy_raw"]
OUT_DIR = "outputs/nested"


# ----------------------------------------------------------------------------
# metrics (all in log10 concentration space)
# ----------------------------------------------------------------------------
def r2(y, mu):
    return 1.0 - np.sum((y - mu) ** 2) / np.sum((y - y.mean()) ** 2)


def metrics(y, mu, sd):
    e = mu - y
    z = e / sd
    return dict(r2=r2(y, mu), mae=np.mean(np.abs(e)),
                nll=np.mean(-norm.logpdf(e, scale=sd)),
                cov68=np.mean(np.abs(z) <= 1.0), cov95=np.mean(np.abs(z) <= 1.96))


def group_bootstrap_r2(y, mu, g, n_boot=1000, seed=0):
    """95% CI of pooled R^2, resampling whole batches (the unit of generalisation)."""
    rng = np.random.default_rng(seed)
    ug = np.unique(g)
    idx = {u: np.where(g == u)[0] for u in ug}
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(ug, len(ug))
        ii = np.concatenate([idx[u] for u in pick])
        vals.append(r2(y[ii], mu[ii]))
    return np.percentile(vals, [2.5, 97.5])


# ----------------------------------------------------------------------------
# inner loop: score every (k, beta) using ONLY the outer-train groups
# ----------------------------------------------------------------------------
def inner_scores(Xtr, ytr, gtr, Model, corr, floor_frac, n_splits=INNER_SPLITS):
    store = {(k, b): dict(y=[], mu=[], sd=[], ne=[]) for k in K_GRID for b in BETA_GRID}
    gkf = GroupKFold(n_splits=min(n_splits, len(np.unique(gtr))))
    for itr, ite in gkf.split(Xtr, ytr, gtr):
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(Xtr[itr], ytr[itr])
        floor = floor_frac * np.std(ytr[itr])
        for k in K_GRID:
            for b in BETA_GRID:
                m.beta, m.k = b, k
                mu, sd, W = m.predict(Xtr[ite])
                s = store[(k, b)]
                s["y"].append(ytr[ite]); s["mu"].append(mu)
                s["sd"].append(np.maximum(sd, floor)); s["ne"].append(L1.n_eff_from_weights(W))
    out = {}
    for c, s in store.items():
        y, mu, sd, ne = (np.concatenate(s[key]) for key in ("y", "mu", "sd", "ne"))
        e2 = (mu - y) ** 2
        out[c] = dict(mse=e2.mean(), se=e2.std(ddof=1) / np.sqrt(len(e2)),
                      nll=np.mean(-norm.logpdf(mu - y, scale=sd)),
                      mse_raw=np.mean((10 ** mu - 10 ** y) ** 2),     # the legacy (buggy) space
                      n_eff=ne.mean())
    return out


def select(policy, sc):
    keys = list(sc)
    if policy == "accuracy":
        return min(keys, key=lambda c: sc[c]["mse"])
    if policy == "calibration":
        return min(keys, key=lambda c: sc[c]["nll"])
    if policy == "legacy_raw":
        return min(keys, key=lambda c: sc[c]["mse_raw"])
    if policy == "accuracy_1se":
        best = min(keys, key=lambda c: sc[c]["mse"])
        thr = sc[best]["mse"] + sc[best]["se"]
        return max((c for c in keys if sc[c]["mse"] <= thr), key=lambda c: sc[c]["n_eff"])
    raise ValueError(policy)


# ----------------------------------------------------------------------------
# outer loop
# ----------------------------------------------------------------------------
def nested_cv(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
              inner_splits=INNER_SPLITS):
    n = len(y)
    pred = {p: dict(mu=np.zeros(n), sd=np.zeros(n)) for p in POLICIES}
    grid = {(k, b): dict(mu=np.zeros(n), sd=np.zeros(n)) for k in K_GRID for b in BETA_GRID}
    gmean = dict(mu=np.zeros(n), sd=np.zeros(n))
    sel_rows = []

    for fold, (tr, te) in enumerate(LeaveOneGroupOut().split(X, y, groups)):
        sc = inner_scores(X[tr], y[tr], groups[tr], Model, corr, floor_frac, inner_splits)
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X[tr], y[tr])
        floor = floor_frac * np.std(y[tr])
        cache = {}
        for k in K_GRID:
            for b in BETA_GRID:
                m.beta, m.k = b, k
                mu, sd, W = m.predict(X[te])
                cache[(k, b)] = (mu, np.maximum(sd, floor), L1.n_eff_from_weights(W).mean())
                grid[(k, b)]["mu"][te], grid[(k, b)]["sd"][te] = cache[(k, b)][:2]
        for p in POLICIES:
            c = select(p, sc)
            pred[p]["mu"][te], pred[p]["sd"][te] = cache[c][:2]
            sel_rows.append(dict(fold=fold, group=groups[te][0], policy=p, k=c[0], beta=c[1],
                                 inner_mse=sc[c]["mse"], outer_n_eff=cache[c][2]))
        gmean["mu"][te] = y[tr].mean()
        gmean["sd"][te] = max(np.std(y[tr]), 1e-6)
    return pred, grid, gmean, pd.DataFrame(sel_rows)


# ----------------------------------------------------------------------------
# reporting
# ----------------------------------------------------------------------------
LABELS = {"accuracy": "nested: accuracy", "accuracy_1se": "nested: accuracy + 1-SE",
          "calibration": "nested: calibration", "legacy_raw": "nested: legacy raw-space (bug)"}


def summarise(y, groups, pred, grid, gmean, sel):
    rows = []

    def add(name, mu, sd, extra=None):
        mt = metrics(y, mu, sd)
        lo, hi = group_bootstrap_r2(y, mu, groups)
        rows.append(dict(method=name, r2=mt["r2"], r2_lo=lo, r2_hi=hi, mae=mt["mae"],
                         nll=mt["nll"], cov68=mt["cov68"], cov95=mt["cov95"], **(extra or {})))

    add("reference: global mean", gmean["mu"], gmean["sd"])
    best_cfg = max(grid, key=lambda c: r2(y, grid[c]["mu"]))
    add(f"reference: best-of-grid k={best_cfg[0]}, beta={best_cfg[1]:g} (OPTIMISTIC)",
        grid[best_cfg]["mu"], grid[best_cfg]["sd"])
    for p in POLICIES:
        s = sel[sel.policy == p]
        add(LABELS[p], pred[p]["mu"], pred[p]["sd"],
            dict(med_k=s["k"].median(), med_beta=s["beta"].median(),
                 mean_n_eff=s["outer_n_eff"].mean(),
                 n_distinct_cfg=len(s.groupby(["k", "beta"]))))
    return pd.DataFrame(rows)


def make_figures(res, sel, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)

    r = res.reset_index(drop=True)
    yerr = np.vstack([r["r2"] - r["r2_lo"], r["r2_hi"] - r["r2"]])
    colors = ["#999999", "#d95f02"] + ["#1b9e77"] * 3 + ["#7570b3"]
    colors = colors[:len(r)]
    ax[0].barh(range(len(r)), r["r2"], xerr=yerr, color=colors, capsize=3)
    ax[0].set_yticks(range(len(r)), [m.split(" k=")[0] for m in r["method"]], fontsize=8)
    ax[0].invert_yaxis(); ax[0].set_xlabel("pooled LOEGO R2 (log10 conc), 95% batch-bootstrap CI")
    ax[0].set_title("Honest (nested) vs optimistic (best-of-grid) accuracy")

    s = sel[sel.policy == "accuracy"]
    H = np.zeros((len(BETA_GRID), len(K_GRID)))
    for _, row in s.iterrows():
        H[BETA_GRID.index(row["beta"]), K_GRID.index(row["k"])] += 1
    im = ax[1].imshow(H, origin="lower", aspect="auto", cmap="Blues")
    ax[1].set_xticks(range(len(K_GRID)), K_GRID)
    ax[1].set_yticks(range(len(BETA_GRID)), [f"{b:g}" for b in BETA_GRID])
    ax[1].set_xlabel("k"); ax[1].set_ylabel("beta")
    ax[1].set_title("Which (k, beta) the accuracy policy chose, per outer fold")
    for i in range(H.shape[0]):
        for j in range(H.shape[1]):
            if H[i, j]:
                ax[1].text(j, i, int(H[i, j]), ha="center", va="center", fontsize=8)
    plt.colorbar(im, ax=ax[1], label="# folds")
    fig.savefig(f"{out_dir}/fig5_nested_cv.png", dpi=160, bbox_inches="tight"); plt.close(fig)


def analyse(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            inner_splits=INNER_SPLITS, out_dir=OUT_DIR):
    groups = np.asarray(groups)
    print(f"\nLayer 2 data: X={X.shape}, groups={len(set(groups))}, inner folds={inner_splits}")
    print("Running nested CV (this does LOEGO x inner GroupKFold x grid) ...")
    pred, grid, gmean, sel = nested_cv(X, y, groups, Model, corr, floor_frac, inner_splits)
    res = summarise(y, groups, pred, grid, gmean, sel)

    os.makedirs(out_dir, exist_ok=True)
    res.to_csv(f"{out_dir}/nested_results.csv", index=False)
    sel.to_csv(f"{out_dir}/selections.csv", index=False)

    pd.set_option("display.width", 200, "display.max_colwidth", 70)
    cols = ["method", "r2", "r2_lo", "r2_hi", "mae", "cov68", "cov95", "nll"]
    print("\n=== OUTER (LOEGO) SCORES, log10 concentration ===")
    print(res[cols].round(3).to_string(index=False))
    print("\n=== WHAT EACH POLICY CHOSE ===")
    print(res.loc[res["med_k"].notna(), ["method", "med_k", "med_beta", "mean_n_eff", "n_distinct_cfg"]]
          .round(2).to_string(index=False))

    nested = res.loc[res.method == LABELS["accuracy"], "r2"].item()
    opt = res.loc[res.method.str.contains("OPTIMISTIC"), "r2"].item()
    leg = res.loc[res.method == LABELS["legacy_raw"], "r2"].item()
    print(f"\nSelection optimism (best-of-grid - nested accuracy): {opt - nested:+.3f} R2")
    print(f"Effect of fixing the scoring-space bug (nested accuracy - legacy raw): {nested - leg:+.3f} R2")
    make_figures(res, sel, out_dir)
    print(f"\nSaved tables + figure in ./{out_dir}/")
    return res, sel
