"""
LAYER 2c -- AN n_eff-TARGET SELECTION POLICY (search one thing, not two)
=========================================================================
Layer 2 searched a 2-D grid of (k, beta). Layer 1 showed n_eff organises accuracy and
calibration, and Layer 3 found the accuracy optimum sits near n_eff ~ 7 without a
detectable trend in n. Layer 2c therefore searches over a TARGET n_eff instead:

    given a training set and a target t, choose beta so that the mean n_eff of
    held-out-like queries equals t  (all voters, k = None).

"Held-out-like" is measured WITHOUT labels or test data: every training droplet is
queried against the training droplets of OTHER batches only (batch-leave-out), which
mimics how an unseen batch sees its neighbours. beta is re-solved for every training
set, so the same target adapts automatically to the amount of data.

Policies compared, same outer LOEGO folds, inner GroupKFold on outer-train batches only:
    grid_acc / grid_1se / grid_cal    : Layer 2's (k, beta) grid policies (reference)
    neff_acc / neff_1se / neff_cal    : same criteria, but searching the 8 n_eff targets
    neff_fixed7  / neff_fixed35       : NO search. Fixed targets taken from Layers 1-3
                                        (accuracy optimum ~7, calibration region ~35).
                                        Mild optimism: those numbers came from this dataset.
Every policy is also reported after the Layer 2b corrections (bias, sigma), fitted on
inner out-of-fold predictions only.

Reported: R2 (+ batch-bootstrap CI), MAE, coverage, and STABILITY (how many distinct
settings were chosen across folds; how much the realised n_eff varied), plus paired R2
differences between policies.

Uses Layer 0 internals m.Z_, m._dist and m.scale_ to compute the batch-leave-out n_eff.

Run:
    neffretrieval neff-policy --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut

from . import bridge as L1
from . import nested as L2
from . import recalibration as L2b

BETA_GRID, K_GRID = L1.BETA_GRID, L1.K_GRID
CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
T_GRID = [3, 5, 7, 10, 15, 25, 35, 50]            # candidate target n_eff values
FIXED_ACC, FIXED_CAL = 7, 35
LNB = np.linspace(np.log(0.02), np.log(200.0), 80)  # beta search range for hitting a target
INNER_SPLITS = 5
POLICIES = ["grid_acc", "grid_1se", "grid_cal", "neff_acc", "neff_1se", "neff_cal",
            "neff_fixed7", "neff_fixed35"]
VARIANTS = L2b.VARIANTS
GRID_CFGS = [(k, b) for k in K_GRID for b in BETA_GRID]
TGT_CFGS = [("neff", t) for t in T_GRID]
OUT_DIR = "outputs/neff_policy"


# ----------------------------------------------------------------------------
# hit a target n_eff by solving for beta (label-free, batch-leave-out)
# ----------------------------------------------------------------------------
def _mean_neff(D, mask, beta):
    s = -beta * D
    s = np.where(mask, -np.inf, s)
    s = s - s.max(axis=1, keepdims=True)
    W = np.exp(s)
    W = W / W.sum(axis=1, keepdims=True)
    return float(np.mean(1.0 / np.sum(W ** 2, axis=1)))


def beta_curve(m, groups):
    """mean batch-leave-out n_eff of the fitted model at each beta on the LNB grid."""
    D = m._dist(m.Z_, m.Z_) / m.scale_
    mask = groups[:, None] == groups[None, :]
    ne = np.array([_mean_neff(D, mask, np.exp(l)) for l in LNB])
    return np.minimum.accumulate(ne)                  # n_eff is non-increasing in beta


def beta_for_target(ne_curve, t):
    if t >= ne_curve[0]:
        return float(np.exp(LNB[0]))
    if t <= ne_curve[-1]:
        return float(np.exp(LNB[-1]))
    return float(np.exp(np.interp(-t, -ne_curve, LNB)))


# ----------------------------------------------------------------------------
# inner loop
# ----------------------------------------------------------------------------
def inner_pass(Xtr, ytr, gtr, Model, corr, floor_frac, n_splits=INNER_SPLITS):
    cfgs = GRID_CFGS + TGT_CFGS
    store = {c: dict(y=[], mu=[], sd=[], ne=[]) for c in cfgs}
    gkf = GroupKFold(n_splits=min(n_splits, len(np.unique(gtr))))
    for itr, ite in gkf.split(Xtr, ytr, gtr):
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(Xtr[itr], ytr[itr])
        floor = floor_frac * np.std(ytr[itr])
        curve = beta_curve(m, gtr[itr])

        def record(c):
            mu, sd, W = m.predict(Xtr[ite])
            s = store[c]
            s["y"].append(ytr[ite]); s["mu"].append(mu)
            s["sd"].append(np.maximum(sd, floor)); s["ne"].append(L1.n_eff_from_weights(W))
        for (k, b) in GRID_CFGS:
            m.beta, m.k = b, k
            record((k, b))
        m.k = None
        for t in T_GRID:
            m.beta = beta_for_target(curve, t)
            record(("neff", t))
    oof, sc = {}, {}
    for c, s in store.items():
        y, mu, sd, ne = (np.concatenate(s[key]) for key in ("y", "mu", "sd", "ne"))
        oof[c] = (y, mu, sd)
        e2 = (mu - y) ** 2
        sc[c] = dict(mse=e2.mean(), se=e2.std(ddof=1) / np.sqrt(len(e2)),
                     nll=np.mean(-norm.logpdf(mu - y, scale=sd)), mse_raw=np.nan, n_eff=ne.mean())
    return oof, sc


def pick(policy, sc):
    sub = lambda cf: {c: sc[c] for c in cf}
    if policy == "grid_acc":
        return L2.select("accuracy", sub(GRID_CFGS))
    if policy == "grid_1se":
        return L2.select("accuracy_1se", sub(GRID_CFGS))
    if policy == "grid_cal":
        return L2.select("calibration", sub(GRID_CFGS))
    if policy == "neff_acc":
        return L2.select("accuracy", sub(TGT_CFGS))
    if policy == "neff_1se":
        return L2.select("accuracy_1se", sub(TGT_CFGS))
    if policy == "neff_cal":
        return L2.select("calibration", sub(TGT_CFGS))
    if policy == "neff_fixed7":
        return ("neff", FIXED_ACC)
    if policy == "neff_fixed35":
        return ("neff", FIXED_CAL)
    raise ValueError(policy)


# ----------------------------------------------------------------------------
# outer loop
# ----------------------------------------------------------------------------
def run(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC, inner=INNER_SPLITS):
    n = len(y)
    out = {p: {v: dict(mu=np.zeros(n), sd=np.zeros(n)) for v in VARIANTS} for p in POLICIES}
    rows = []
    for fold, (tr, te) in enumerate(LeaveOneGroupOut().split(X, y, groups)):
        oof, sc = inner_pass(X[tr], y[tr], groups[tr], Model, corr, floor_frac, inner)
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X[tr], y[tr])
        floor = floor_frac * np.std(y[tr])
        curve = beta_curve(m, groups[tr])
        cache = {}
        for (k, b) in GRID_CFGS:
            m.beta, m.k = b, k
            mu, sd, W = m.predict(X[te])
            cache[(k, b)] = (mu, np.maximum(sd, floor), L1.n_eff_from_weights(W).mean(), b)
        m.k = None
        for t in T_GRID:
            b = beta_for_target(curve, t)
            m.beta = b
            mu, sd, W = m.predict(X[te])
            cache[("neff", t)] = (mu, np.maximum(sd, floor), L1.n_eff_from_weights(W).mean(), b)
        for pol in POLICIES:
            cfg = pick(pol, sc)
            mu, sd, ne_mean, b_used = cache[cfg]
            c = L2b.fit_corrections(*oof[cfg])
            for v, (mu_v, sd_v) in L2b.apply_variants(mu, sd, c).items():
                out[pol][v]["mu"][te], out[pol][v]["sd"][te] = mu_v, sd_v
            rows.append(dict(fold=fold, policy=pol, cfg=str(cfg), beta_used=b_used, outer_n_eff=ne_mean,
                             slope=c["slope"], s_raw=c["s_raw"]))
    return out, pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# reporting
# ----------------------------------------------------------------------------
def table(out, y, groups):
    rows = []
    for pol in POLICIES:
        for v in VARIANTS:
            mu, sd = out[pol][v]["mu"], out[pol][v]["sd"]
            mt = L2.metrics(y, mu, sd)
            lo, hi = L2.group_bootstrap_r2(y, mu, groups)
            rows.append(dict(policy=pol, variant=v, r2=mt["r2"], r2_lo=lo, r2_hi=hi, mae=mt["mae"],
                             cov68=mt["cov68"], cov95=mt["cov95"], nll=mt["nll"]))
    return pd.DataFrame(rows)


def stability(sel):
    rows = []
    for pol in POLICIES:
        s = sel[sel.policy == pol]
        top = s.cfg.value_counts()
        rows.append(dict(policy=pol, distinct_settings=s.cfg.nunique(), most_common=top.index[0],
                         most_common_folds=int(top.iloc[0]), n_eff_mean=s.outer_n_eff.mean(),
                         n_eff_sd=s.outer_n_eff.std(), beta_min=s.beta_used.min(), beta_max=s.beta_used.max()))
    return pd.DataFrame(rows)


def make_figure(tab, stab, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(17, 5), constrained_layout=True)
    raw = tab[tab.variant == "raw"].reset_index(drop=True)
    col = ["#999999"] * 3 + ["#1b9e77"] * 3 + ["#7570b3"] * 2
    yerr = np.vstack([raw.r2 - raw.r2_lo, raw.r2_hi - raw.r2])
    ax[0].barh(range(len(raw)), raw.r2, xerr=yerr, color=col, capsize=3)
    ax[0].set_yticks(range(len(raw)), raw.policy); ax[0].invert_yaxis()
    ax[0].set_xlabel("pooled LOEGO R2 (log10), 95% batch-bootstrap CI"); ax[0].set_title("Accuracy (raw)")
    x = np.arange(len(raw))
    ax[1].bar(x - 0.2, raw.cov95, 0.4, label="cov95"); ax[1].bar(x + 0.2, raw.cov68, 0.4, label="cov68")
    ax[1].axhline(0.95, color="C0", ls=":"); ax[1].axhline(0.68, color="C1", ls=":")
    ax[1].set_xticks(x, raw.policy, rotation=45, ha="right"); ax[1].set_ylim(0, 1.05); ax[1].legend()
    ax[1].set_title("Calibration (raw, no correction)")
    ax[2].bar(range(len(stab)), stab.distinct_settings, color=col)
    ax[2].set_xticks(range(len(stab)), stab.policy, rotation=45, ha="right")
    ax[2].set_ylabel("# distinct settings chosen across outer folds"); ax[2].set_title("Selection stability (lower = steadier)")
    fig.savefig(f"{out_dir}/fig9_neff_policy.png", dpi=160, bbox_inches="tight"); plt.close(fig)


def analyse(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            inner=INNER_SPLITS, out_dir=OUT_DIR):
    groups = np.asarray(groups)
    print(f"\nLayer 2c data: X={X.shape}, groups={len(set(groups))}, inner folds={inner}, "
          f"n_eff targets={T_GRID}")
    print("Running nested LOEGO (grid policies + n_eff-target policies) ...")
    out, sel = run(X, y, groups, Model, corr, floor_frac, inner)
    os.makedirs(out_dir, exist_ok=True)
    tab, stab = table(out, y, groups), stability(sel)
    tab.to_csv(f"{out_dir}/policy_results.csv", index=False)
    sel.to_csv(f"{out_dir}/selections.csv", index=False)
    stab.to_csv(f"{out_dir}/stability.csv", index=False)
    pd.set_option("display.width", 220, "display.max_colwidth", 40)

    print("\n=== OUTER (LOEGO) SCORES, raw (no correction), log10 concentration ===")
    print(tab[tab.variant == "raw"].drop(columns="variant").round(3).to_string(index=False))
    print("\n=== AFTER THE LAYER 2b CORRECTIONS (bias + sigma) ===")
    print(tab[tab.variant == "bias+sigma"].drop(columns="variant").round(3).to_string(index=False))

    print("\n=== STABILITY OF SELECTION ACROSS OUTER FOLDS ===")
    print(stab.round(2).to_string(index=False))

    print("\n=== PAIRED R2 DIFFERENCES (95% CI by resampling batches; CI containing 0 = no resolvable gap) ===")
    g = lambda p, v: out[p][v]["mu"]
    for a, va, b, vb in [("neff_acc", "raw", "grid_acc", "raw"), ("neff_1se", "raw", "grid_1se", "raw"),
                         ("neff_cal", "raw", "grid_cal", "raw"), ("neff_fixed7", "raw", "grid_acc", "raw"),
                         ("neff_fixed35", "raw", "grid_cal", "raw"),
                         ("neff_cal", "bias+sigma", "grid_cal", "bias+sigma"),
                         ("neff_acc", "bias+sigma", "grid_acc", "bias+sigma")]:
        d, (lo, hi) = L2b.paired_r2_diff(y, g(a, va), g(b, vb), groups)
        print(f"   {a}[{va}] - {b}[{vb}]: {d:+.3f}   CI [{lo:+.3f}, {hi:+.3f}]")
    make_figure(tab, stab, out_dir)
    print(f"\nSaved tables + figure in ./{out_dir}/")
    return out, tab, stab, sel
