"""Data helpers: a synthetic many-to-one benchmark and a generic CSV loader.

Real data are never bundled with this repository. Bring your own table with one row per sample,
a numeric target, a grouping column (batch / subject / site) and numeric feature columns.
"""
import numpy as np
import pandas as pd


def make_synthetic(n=142, n_features=40, n_groups=32, seed=0, noise=0.15):
    """Toy problem with batch structure. A latent variable drives 8 features; a batch effect shifts 4 more.

    Returns ``X, y, groups`` where ``y`` is on a log scale.
    """
    rng = np.random.default_rng(seed)
    latent = rng.normal(size=n)
    X = rng.normal(size=(n, n_features))
    X[:, :8] += latent[:, None] * 1.2
    batch_shift = rng.normal(scale=0.3, size=n_groups)
    gi = np.arange(n) % n_groups
    groups = np.array([f"batch{i:02d}" for i in gi])
    X[:, 8:12] += batch_shift[gi][:, None]  # batch effects the model must generalise across
    y = 0.5 * latent + noise * rng.normal(size=n) - 1.5
    return X, y, groups


def load_csv(path, target, group, features=None, log10_target=False):
    """Load a table. Returns ``X, y, groups, feature_names, frame``.

    ``features`` is a list of column names; default is every numeric column except target/group.
    With ``log10_target`` the target is replaced by its base-10 log (rows with target <= 0 are dropped).
    """
    frame = pd.read_csv(path)
    for col in (target, group):
        if col not in frame.columns:
            raise KeyError(f"column '{col}' not found in {path}; columns are {list(frame.columns)}")
    if log10_target:
        keep = frame[target] > 0
        if not keep.all():
            print(f"dropping {int((~keep).sum())} rows with non-positive target (log10 undefined)")
            frame = frame.loc[keep].reset_index(drop=True)
        frame = frame.assign(**{target: np.log10(frame[target])})
    if features is None:
        features = [c for c in frame.select_dtypes("number").columns if c not in (target, group)]
    X = frame[features].to_numpy(float)
    return X, frame[target].to_numpy(float), frame[group].astype(str).to_numpy(), list(features), frame
