"""
Base associative-retrieval model (leakage-safe).

Predicts a target from a feature vector by similarity-weighted retrieval over stored training
patterns. Weights are a softmax kernel over distances,

    w_i  proportional to  exp(-beta * d(x, z_i) / s),   over the k nearest stored patterns,

with ONE sharpness knob ``beta`` (modern-Hopfield style): beta -> infinity is 1-NN, beta = 0 is the
global mean. Distances are divided by ``s``, the median nearest-neighbour distance of the TRAINING
set, so beta is dimensionless and comparable across folds and dataset sizes.

``predict`` always returns the full weight matrix ``W`` so the analysis layers can compute the
effective sample size n_eff = 1 / sum(w**2), entropy, calibration and so on without touching the
model again.

Internal controls: ``beta`` (sharpness), ``k`` (top-k truncation; None = all), ``metric``,
``feat_weights`` and ``corr_threshold`` (drop features whose |Pearson corr| with the target, on
TRAINING rows only, is below the threshold).
"""
import numpy as np
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.preprocessing import StandardScaler


class AssociativeRetrieval:
    def __init__(self, beta=4.0, k=None, metric="euclidean", feat_weights=None, corr_threshold=None):
        self.beta, self.k, self.metric, self.fw = beta, k, metric, feat_weights
        self.corr_threshold = corr_threshold

    def fit(self, X, y):
        X = np.asarray(X, float)
        self.y_ = np.asarray(y, float)
        self.med_ = np.nanmedian(X, axis=0)
        self.med_ = np.where(np.isnan(self.med_), 0.0, self.med_)
        X = np.where(np.isnan(X), self.med_, X)
        self.scaler_ = StandardScaler().fit(X)
        Zs = self.scaler_.transform(X)
        if self.corr_threshold is not None:
            self.fw_ = self._corr_mask(Zs, self.y_, self.corr_threshold)
        else:
            self.fw_ = self.fw
        self.Z_ = self._embed(Zs)
        D = self._dist(self.Z_, self.Z_)
        np.fill_diagonal(D, np.inf)
        self.scale_ = np.median(D.min(axis=1))  # typical nearest-neighbour distance (train only)
        return self

    @staticmethod
    def _corr_mask(Zs, y, thr):
        """Keep features with |corr(feature, y)| >= thr; survivors get equal weight (mean weight 1)."""
        d = Zs.shape[1]
        corr = np.zeros(d)
        if np.std(y) > 1e-12:
            for j in range(d):
                if np.std(Zs[:, j]) > 1e-12:
                    c = np.corrcoef(Zs[:, j], y)[0, 1]
                    corr[j] = 0.0 if np.isnan(c) else abs(c)
        keep = corr >= thr
        if keep.sum() == 0:  # nothing survived -> uniform
            return np.ones(d)
        return keep * (d / keep.sum())

    def _embed(self, Z):
        if self.fw_ is not None:
            Z = Z * self.fw_
        if self.metric == "cosine":
            Z = Z / np.maximum(np.linalg.norm(Z, axis=1, keepdims=True), 1e-12)
        return Z

    def _dist(self, A, B):
        d2 = (A ** 2).sum(1)[:, None] + (B ** 2).sum(1)[None, :] - 2 * A @ B.T
        return np.sqrt(np.maximum(d2, 0.0))

    def weights(self, Xq):
        Xq = np.asarray(Xq, float)
        Xq = np.where(np.isnan(Xq), self.med_, Xq)
        Zq = self._embed(self.scaler_.transform(Xq))
        s = -self.beta * self._dist(Zq, self.Z_) / self.scale_  # logits
        if self.k is not None and self.k < s.shape[1]:
            kth = -np.partition(-s, self.k - 1, axis=1)[:, self.k - 1:self.k]
            s = np.where(s >= kth, s, -np.inf)  # keep top-k
        s -= s.max(axis=1, keepdims=True)
        W = np.exp(s)
        return W / W.sum(axis=1, keepdims=True)

    def predict(self, Xq):
        """Returns (mean, spread, W): weighted mean, weighted label spread, and the weight matrix."""
        W = self.weights(Xq)
        mu = W @ self.y_
        var = W @ self.y_ ** 2 - mu ** 2
        return mu, np.sqrt(np.maximum(var, 0.0)), W


def loego(X, y, groups, **model_kw):
    """Leave-one-experimental-group-out. Returns pooled predictions and per-query n_eff."""
    mu, sd, neff, yt, gi = [], [], [], [], []
    for tr, te in LeaveOneGroupOut().split(X, y, groups):
        m = AssociativeRetrieval(**model_kw).fit(X[tr], y[tr])
        p, s, W = m.predict(X[te])
        mu.append(p); sd.append(s); yt.append(y[te])
        neff.append(1.0 / (W ** 2).sum(1)); gi += [groups[te][0]] * len(te)
    out = dict(y_true=np.concatenate(yt), y_pred=np.concatenate(mu),
               y_std=np.concatenate(sd), n_eff=np.concatenate(neff), groups=np.array(gi))
    out["r2"] = r2_score(out["y_true"], out["y_pred"])
    out["mae"] = mean_absolute_error(out["y_true"], out["y_pred"])
    return out
