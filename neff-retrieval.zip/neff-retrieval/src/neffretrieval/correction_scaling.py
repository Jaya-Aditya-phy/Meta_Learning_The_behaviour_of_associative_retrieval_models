"""
LAYER 3b -- DO THE LAYER 2b CORRECTIONS STABILISE AS DATA GROWS?
=================================================================
Layer 2b fitted two small corrections from inner out-of-fold predictions:
    bias  : y ~ icpt + slope * prediction
    sigma : one inflation factor s on the interval width
Layer 3b asks how those fitted corrections (and what they buy) depend on the
amount of training data:
    * does the fitted slope settle near 1 (or near a stable value) as n grows?
    * does the sigma factor stop hitting its cap and stop jumping between fits?
    * at which training size do the corrections start paying off (coverage, R2)?

To isolate the effect of n, each model uses ONE fixed configuration (defaults are the
settings chosen most often in Layers 1-2b; override on the command line):
    retrieval_acc : k=9,   beta=2
    retrieval_cal : k=100, beta=1
    knn           : k=5   (uniform weights; retrieval with beta ~ 0)
    density_knn   : k=5   (density-weighted, the density-weighted kNN predictor)

Procedure (outer LOEGO, held-out batch never touches the corrections):
    train on a random subset of the outer-train batches (20%..100%, REPS draws each);
    inner GroupKFold on that SUBSET -> out-of-fold predictions -> fit the corrections;
    apply them to the held-out batch; pool the held-out predictions over all folds.

Run:
    neffretrieval correction-scaling --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import spearmanr
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut

from . import bridge as L1
from . import nested as L2
from . import recalibration as L2b

FRACS = [0.2, 0.3, 0.4, 0.5, 0.65, 0.8, 1.0]
REPS = 3
INNER_SPLITS = 5
CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
VARIANTS = L2b.VARIANTS
SIGMA_CAP = 5.0                       # fit_corrections clips the factor to [0.5, 5]
OUT_DIR = "outputs/correction_scaling"


def default_specs(acc_k, acc_b, cal_k, cal_b, knn_k, dens_k):
    return {"retrieval_acc": ("ret", acc_k, acc_b), "retrieval_cal": ("ret", cal_k, cal_b),
            "knn": ("ret", knn_k, L2b.KNN_BETA), "density_knn": ("dens", dens_k)}


def predict_spec(spec, m, dm, Xq):
    if spec[0] == "dens":
        mu, sd, W, _, _ = dm.predict(Xq, spec[1])
    else:
        m.k, m.beta = spec[1], spec[2]
        mu, sd, W = m.predict(Xq)
    return mu, sd


# ----------------------------------------------------------------------------
# collection
# ----------------------------------------------------------------------------
def collect(X, y, groups, Model, dens_factory, specs, corr, floor_frac, reps, inner, seed):
    rng = np.random.default_rng(seed)
    folds = list(LeaveOneGroupOut().split(X, y, groups))
    n, L = len(y), len(FRACS)
    R = max(reps, 1)
    P = {nm: {v: dict(mu=np.full((L, R, n), np.nan), sd=np.full((L, R, n), np.nan)) for v in VARIANTS}
         for nm in specs}
    rows = []
    for f, (tr, te) in enumerate(folds):
        gtr = np.unique(groups[tr])
        for l, frac in enumerate(FRACS):
            ng = max(4, int(round(frac * len(gtr))))
            full = ng >= len(gtr)
            for r in range(1 if full else R):
                pick = gtr if full else rng.choice(gtr, ng, replace=False)
                sub = tr[np.isin(groups[tr], pick)]
                Xs, ys, gs = X[sub], y[sub], groups[sub]
                # inner folds on the SUBSET only: fit models once, reuse for every spec
                inner_fits = []
                for itr, ite in GroupKFold(n_splits=min(inner, len(pick))).split(Xs, ys, gs):
                    mi = Model(beta=1.0, k=None, corr_threshold=corr).fit(Xs[itr], ys[itr])
                    di = dens_factory().fit(Xs[itr], ys[itr])
                    inner_fits.append((ite, itr, mi, di))
                m = Model(beta=1.0, k=None, corr_threshold=corr).fit(Xs, ys)
                dm = dens_factory().fit(Xs, ys)
                floor = floor_frac * np.std(ys)
                for nm, spec in specs.items():
                    yo, muo, sdo = [], [], []
                    for ite, itr, mi, di in inner_fits:
                        mu, sd = predict_spec(spec, mi, di, Xs[ite])
                        yo.append(ys[ite]); muo.append(mu)
                        sdo.append(np.maximum(sd, floor_frac * np.std(ys[itr])))
                    c = L2b.fit_corrections(np.concatenate(yo), np.concatenate(muo), np.concatenate(sdo))
                    mu, sd = predict_spec(spec, m, dm, X[te])
                    sd = np.maximum(sd, floor)
                    for v, (mu_v, sd_v) in L2b.apply_variants(mu, sd, c).items():
                        P[nm][v]["mu"][l, r, te], P[nm][v]["sd"][l, r, te] = mu_v, sd_v
                    rows.append(dict(model=nm, fold=f, level=l, rep=r, n_train=len(sub),
                                     slope=c["slope"], icpt=c["icpt"], s_raw=c["s_raw"], s_bias=c["s_bias"]))
    return P, pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# summaries
# ----------------------------------------------------------------------------
def q25(s): return np.percentile(s, 25)
def q75(s): return np.percentile(s, 75)


def summarise(P, rows, y, specs):
    L = len(FRACS)
    out = {}
    for nm in specs:
        recs = []
        d = rows[rows.model == nm]
        for l in range(L):
            dl = d[d.level == l]
            rec = dict(level=l, n_train=dl.n_train.mean(),
                       slope_med=dl.slope.median(), slope_q25=q25(dl.slope), slope_q75=q75(dl.slope),
                       slope_iqr=q75(dl.slope) - q25(dl.slope),
                       lns_med=np.log(dl.s_raw).median(), lns_iqr=q75(np.log(dl.s_raw)) - q25(np.log(dl.s_raw)),
                       s_med=dl.s_raw.median(), frac_cap=float((dl.s_raw >= SIGMA_CAP - 1e-6).mean()))
            for v in VARIANTS:
                vals = []
                for r in range(P[nm][v]["mu"].shape[1]):
                    mu, sd = P[nm][v]["mu"][l, r], P[nm][v]["sd"][l, r]
                    if np.isnan(mu).any():
                        continue
                    vals.append(L2.metrics(y, mu, sd))
                for key in ("r2", "mae", "cov68", "cov95"):
                    rec[f"{key}_{v}"] = float(np.mean([m[key] for m in vals]))
                rec[f"r2sd_{v}"] = float(np.std([m["r2"] for m in vals])) if len(vals) > 1 else np.nan
            recs.append(rec)
        out[nm] = pd.DataFrame(recs)
    return out


def report(summ):
    pd.set_option("display.width", 220)
    print("\nCAVEAT: at 100% of the training batches the outer folds share almost all their data (each leaves out "
          "one batch), so the spread of the fitted corrections there is UNDERESTIMATED relative to the smaller "
          "sizes, where each fold trains on a different random subset. Read the drop in IQR as 'fits become "
          "more consistent with more data', not as a precise rate.")
    for nm, t in summ.items():
        print(f"\n{'=' * 90}\nMODEL: {nm}\n{'=' * 90}")
        print("fitted corrections by training size (median and IQR over outer folds x draws):")
        print(t[["n_train", "slope_med", "slope_iqr", "s_med", "lns_iqr", "frac_cap"]].round(3).to_string(index=False))
        print("\nwhat the corrections buy (pooled held-out LOEGO, mean over draws):")
        print(t[["n_train", "r2_raw", "r2_bias", "cov68_raw", "cov68_sigma", "cov95_raw", "cov95_sigma"]]
              .round(3).to_string(index=False))
        rho_i, _ = spearmanr(t.n_train, t.slope_iqr)
        rho_c, _ = spearmanr(t.n_train, t.lns_iqr)
        rho_g, _ = spearmanr(t.n_train, t.cov95_sigma - t.cov95_raw)
        print(f"\ntrend with n (Spearman, 7 sizes -> weak evidence): slope IQR {rho_i:+.2f}; "
              f"ln(sigma factor) IQR {rho_c:+.2f}; coverage gain from sigma fix {rho_g:+.2f}")
        print(f"slope IQR: {t.slope_iqr.iloc[0]:.3f} at n={t.n_train.iloc[0]:.0f}  ->  "
              f"{t.slope_iqr.iloc[-1]:.3f} at n={t.n_train.iloc[-1]:.0f};   "
              f"sigma factor at cap: {t.frac_cap.iloc[0] * 100:.0f}% -> {t.frac_cap.iloc[-1] * 100:.0f}% of fits")


def make_figure(summ, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    fig, ax = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
    for i, (nm, t) in enumerate(summ.items()):
        c = f"C{i}"
        ax[0, 0].plot(t.n_train, t.slope_med, "o-", color=c, label=nm)
        ax[0, 0].fill_between(t.n_train, t.slope_q25, t.slope_q75, color=c, alpha=0.15)
        ax[0, 1].plot(t.n_train, t.s_med, "o-", color=c, label=nm)
        ax[1, 0].plot(t.n_train, t.cov95_raw, "o--", color=c, alpha=0.7)
        ax[1, 0].plot(t.n_train, t.cov95_sigma, "s-", color=c, label=nm)
        ax[1, 1].plot(t.n_train, t.r2_raw, "o--", color=c, alpha=0.7)
        ax[1, 1].plot(t.n_train, t.r2_bias, "s-", color=c, label=nm)
    ax[0, 0].axhline(1, color="k", ls=":"); ax[0, 0].set_ylabel("fitted bias slope (1 = no bias)")
    ax[0, 0].set_title("Bias slope vs training size (band = IQR)")
    ax[0, 1].axhline(SIGMA_CAP, color="r", ls=":", label="cap"); ax[0, 1].axhline(1, color="k", ls=":")
    ax[0, 1].set_ylabel("sigma inflation factor (1 = intervals fine)"); ax[0, 1].set_title("Sigma factor vs training size")
    ax[1, 0].axhline(0.95, color="k", ls=":"); ax[1, 0].set_ylabel("coverage of nominal 95% interval")
    ax[1, 0].set_title("95% coverage: raw (dashed) vs sigma-corrected (solid)")
    ax[1, 1].set_ylabel("pooled held-out R2 (log10)"); ax[1, 1].set_title("R2: raw (dashed) vs bias-corrected (solid)")
    for a in ax.ravel():
        a.set_xlabel("n_train"); a.set_xscale("log")
    ax[0, 0].legend(fontsize=8)
    fig.savefig(f"{out_dir}/fig8_correction_scaling.png", dpi=160, bbox_inches="tight"); plt.close(fig)


def analyse(X, y, groups, Model, specs, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            reps=REPS, inner=INNER_SPLITS, out_dir=OUT_DIR, base=None, seed=0):
    groups = np.asarray(groups)
    corr_fn, dens_fn = L2b.make_density_helpers(base)
    dens_factory = lambda: L2b.DensityKNN(corr_fn, dens_fn)
    print(f"\nLayer 3b data: X={X.shape}, groups={len(set(groups))}, levels={FRACS}, draws={reps}")
    print("fixed configs:", {k: v for k, v in specs.items()})
    print("Collecting subsampled nested runs (fits corrections inside every subsample) ...")
    P, rows = collect(X, y, groups, Model, dens_factory, specs, corr, floor_frac, reps, inner, seed)
    summ = summarise(P, rows, y, specs)
    os.makedirs(out_dir, exist_ok=True)
    rows.to_csv(f"{out_dir}/fitted_corrections_by_size.csv", index=False)
    for nm, t in summ.items():
        t.to_csv(f"{out_dir}/summary_{nm}.csv", index=False)
    report(summ)
    make_figure(summ, out_dir)
    print(f"\nSaved tables + figure in ./{out_dir}/")
    return summ, rows
