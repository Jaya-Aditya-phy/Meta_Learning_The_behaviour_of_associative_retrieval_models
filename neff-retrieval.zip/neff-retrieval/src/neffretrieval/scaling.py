"""
LAYER 3 -- THE SCALING LAW (how should the controls move as data grows?)
=========================================================================
Layer 1: accuracy / calibration are organised by n_eff.
Layer 2: (k, beta) can be chosen honestly.
Layer 3: how does the right setting change with training-set size n?

Hypothesis (k = all voters, so beta is the only control):

    n_eff / n_train  ~  A * exp(-c * beta)                       (law)

If the accuracy-optimal setting sits at a roughly constant n_eff* then

    beta*(n) = (1/c) * ln( A * n / n_eff* )                      (prediction)

i.e. the best beta grows like ln(n) with slope 1/c.

How it is tested (all on held-out batches, LOEGO outer loop):
  * train sets are random SUBSETS of the outer-train batches (20% ... 100%),
    several random draws per level, so n varies while the held-out batch is fixed;
  * the law (A, c, n_eff*) is fitted on the SMALL half of the n levels only and
    must predict beta* on the LARGE half (out-of-sample), against a "beta* is
    constant" null;
  * two length-scale modes: 'adaptive' (Layer 0 default: median NN distance of the
    stored set, which shrinks as n grows) and 'fixed' (median NN distance of a
    fixed-size reference sample, n-independent). If c and the prediction survive in
    'fixed' mode, the law is not just an artefact of Layer 0's normalisation.
  * 95% CIs by resampling held-out batches.

Needs Layer 1 and the Layer 0 file in the same folder (uses Layer 0 internals
m.Z_, m._dist and m.scale_ only to define the 'fixed' length scale).

Run:
    neffretrieval scaling --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import LeaveOneGroupOut

from . import bridge as L1

BETA_GRID3 = [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8, 12, 16, 24, 32]
BETA = np.array(BETA_GRID3, float)
FRACS = [0.2, 0.3, 0.4, 0.5, 0.65, 0.8, 1.0]      # fraction of outer-train batches used
REPS = 4                                           # random draws per (fold, level<100%)
NEFF_MIN_FIT = 2.0                                 # n_eff floors at 1, so fit above it
N_REF_SCALE = 20                                   # reference size for the 'fixed' length scale
N_EXTRAP = [206, 300]                              # sizes beyond the data, for falsifiable predictions
N_BOOT = 300
CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
OUT_DIR = "outputs/scaling"
S_REPS, S_NTR, S_NQ, S_NEFF, S_SQ, S_C68, S_C95 = range(7)


# ----------------------------------------------------------------------------
# 1. data collection: one table of sufficient statistics, folds x levels x beta
# ----------------------------------------------------------------------------
def collect(X, y, groups, Model, corr, floor_frac, scale_mode, reps, seed):
    rng = np.random.default_rng(seed)
    folds = list(LeaveOneGroupOut().split(X, y, groups))
    T = np.zeros((len(folds), len(FRACS), len(BETA), 7))
    for f, (tr, te) in enumerate(folds):
        gtr = np.unique(groups[tr])
        for l, frac in enumerate(FRACS):
            ng = max(3, int(round(frac * len(gtr))))
            full = ng >= len(gtr)
            for _ in range(1 if full else reps):
                pick = gtr if full else rng.choice(gtr, ng, replace=False)
                sub = tr[np.isin(groups[tr], pick)]
                m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X[sub], y[sub])
                if scale_mode == "fixed":
                    idx = rng.choice(len(sub), min(N_REF_SCALE, len(sub)), replace=False)
                    D = m._dist(m.Z_[idx], m.Z_[idx])
                    np.fill_diagonal(D, np.inf)
                    m.scale_ = np.median(D.min(axis=1))
                floor = floor_frac * np.std(y[sub])
                for b, beta in enumerate(BETA):
                    m.beta = beta
                    mu, sd, W = m.predict(X[te])
                    e = mu - y[te]
                    z = e / np.maximum(sd, floor)
                    T[f, l, b] += [1, len(sub), len(te), L1.n_eff_from_weights(W).sum(),
                                   (e ** 2).sum(), (np.abs(z) <= 1.0).sum(), (np.abs(z) <= 1.96).sum()]
    return T


def aggregate(T, w):
    S = np.einsum("f,flbs->lbs", w, T)
    nq = S[:, :, S_NQ]
    return dict(ntr=S[:, 0, S_NTR] / S[:, 0, S_REPS], neff=S[:, :, S_NEFF] / nq,
                mse=S[:, :, S_SQ] / nq, cov68=S[:, :, S_C68] / nq, cov95=S[:, :, S_C95] / nq)


# ----------------------------------------------------------------------------
# 2. the law and its consequences
# ----------------------------------------------------------------------------
def fit_law(ntr, neff, min_neff=NEFF_MIN_FIT):
    """ln(n_eff / n_train) = ln A - c * beta, using points with n_eff above its floor of 1."""
    Bg, Ng = np.meshgrid(BETA, np.atleast_1d(ntr))
    ne = np.atleast_2d(neff)
    m = ne >= min_neff
    xs, ys = Bg[m], np.log(ne[m] / Ng[m])
    A = np.c_[np.ones_like(xs), xs]
    coef = np.linalg.lstsq(A, ys, rcond=None)[0]
    res = ys - A @ coef
    return dict(lnA=coef[0], c=-coef[1], r2=1.0 - (res ** 2).sum() / ((ys - ys.mean()) ** 2).sum())


def argmin_refined(vals):
    """beta at the minimum of vals, refined by a parabola in ln(beta)."""
    i = int(np.nanargmin(vals))
    lb = np.log(BETA)
    if 0 < i < len(vals) - 1:
        a, b, _ = np.polyfit(lb[i - 1:i + 2], vals[i - 1:i + 2], 2)
        if a > 0:
            return float(np.exp(np.clip(-b / (2 * a), lb[i - 1], lb[i + 1])))
    return float(BETA[i])


def crossing(cov, target):
    """beta where coverage (falling with beta) crosses the nominal level; NaN if it never does."""
    lb = np.log(BETA)
    for i in range(len(BETA) - 1):
        if cov[i] >= target > cov[i + 1]:
            t = (cov[i] - target) / (cov[i] - cov[i + 1])
            return float(np.exp(lb[i] + t * (lb[i + 1] - lb[i])))
    return np.nan


def neff_at(beta_star, neff_row):
    return float(np.exp(np.interp(np.log(beta_star), np.log(BETA), np.log(neff_row))))


def beta_pred(n, law, neff_star):
    return (np.log(n) + law["lnA"] - np.log(neff_star)) / law["c"]


def study(T, w):
    a = aggregate(T, w)
    L = len(a["ntr"])
    b_acc = np.array([argmin_refined(a["mse"][l]) for l in range(L)])
    n_star = np.array([neff_at(b_acc[l], a["neff"][l]) for l in range(L)])
    b_cal = np.array([crossing(a["cov95"][l], 0.95) for l in range(L)])
    c_by_level = np.array([fit_law(a["ntr"][l], a["neff"][l])["c"] for l in range(L)])

    h = (L + 1) // 2
    lo, hi = slice(0, h), slice(h, L)
    law_lo = fit_law(a["ntr"][lo], a["neff"][lo])
    nstar_lo = float(np.exp(np.mean(np.log(n_star[lo]))))
    pred_hi = beta_pred(a["ntr"][hi], law_lo, nstar_lo)
    const = float(np.exp(np.mean(np.log(b_acc[lo]))))
    err_law = float(np.mean(np.abs(np.log(pred_hi) - np.log(b_acc[hi]))))
    err_const = float(np.mean(np.abs(np.log(const) - np.log(b_acc[hi]))))

    # variant B: let n_eff* itself scale with n:  n_eff*(n) = exp(g0) * n^gamma  (fitted on the small half)
    gam_lo, g0_lo = np.polyfit(np.log(a["ntr"][lo]), np.log(n_star[lo]), 1)
    pred_hi_pow = beta_pred(a["ntr"][hi], law_lo, np.exp(g0_lo + gam_lo * np.log(a["ntr"][hi])))
    err_pow = float(np.mean(np.abs(np.log(pred_hi_pow) - np.log(b_acc[hi]))))

    law_all = fit_law(a["ntr"], a["neff"])
    nstar_all = float(np.exp(np.mean(np.log(n_star))))
    extrap = {n: float(beta_pred(n, law_all, nstar_all)) for n in N_EXTRAP}
    gam_all, g0_all = np.polyfit(np.log(a["ntr"]), np.log(n_star), 1)
    extrap_pow = {n: float(beta_pred(n, law_all, np.exp(g0_all + gam_all * np.log(n)))) for n in N_EXTRAP}
    return dict(a=a, b_acc=b_acc, n_star=n_star, b_cal=b_cal, c_by_level=c_by_level,
                law_lo=law_lo, nstar_lo=nstar_lo, pred_hi=pred_hi, const=const,
                err_law=err_law, err_const=err_const, law_all=law_all,
                nstar_all=nstar_all, extrap=extrap, h=h,
                gamma=float(gam_all), g0=float(g0_all), pred_hi_pow=pred_hi_pow, err_pow=err_pow,
                extrap_pow=extrap_pow)


def bootstrap(T, n_boot, seed=0):
    rng = np.random.default_rng(seed)
    F = T.shape[0]
    keys = ["c", "lnA", "nstar", "err_gain", "gamma", "err_gain_pow"] + \
           [f"beta@{n}" for n in N_EXTRAP] + [f"betapow@{n}" for n in N_EXTRAP]
    out = {k: [] for k in keys}
    for _ in range(n_boot):
        w = rng.multinomial(F, np.ones(F) / F).astype(float)
        try:
            s = study(T, w)
        except Exception:
            continue
        out["c"].append(s["law_all"]["c"]); out["lnA"].append(s["law_all"]["lnA"])
        out["nstar"].append(s["nstar_all"]); out["err_gain"].append(s["err_const"] - s["err_law"])
        out["gamma"].append(s["gamma"]); out["err_gain_pow"].append(s["err_const"] - s["err_pow"])
        for n in N_EXTRAP:
            out[f"beta@{n}"].append(s["extrap"][n]); out[f"betapow@{n}"].append(s["extrap_pow"][n])
    return {k: np.nanpercentile(v, [2.5, 97.5]) for k, v in out.items() if len(v)}


# ----------------------------------------------------------------------------
# 3. reporting
# ----------------------------------------------------------------------------
def report(mode, s, ci):
    a = s["a"]
    print(f"\n{'=' * 78}\nLENGTH-SCALE MODE: {mode}\n{'=' * 78}")
    tab = pd.DataFrame(dict(n_train=a["ntr"].round(0), beta_star_acc=s["b_acc"],
                            neff_at_acc_opt=s["n_star"], beta_cal_cov95=s["b_cal"],
                            c_this_level=s["c_by_level"]))
    print(tab.round(3).to_string(index=False))
    la = s["law_all"]
    print(f"\nLaw (all levels):  n_eff/n = {np.exp(la['lnA']):.3f} * exp(-{la['c']:.3f} * beta)"
          f"   R2={la['r2']:.3f}   c 95% CI [{ci['c'][0]:.3f}, {ci['c'][1]:.3f}]")
    print(f"n_eff* at the accuracy optimum (geometric mean over levels): {s['nstar_all']:.2f}"
          f"   CI [{ci['nstar'][0]:.2f}, {ci['nstar'][1]:.2f}]")
    print(f"n_eff* growth: n_eff*(n) ~ n^{s['gamma']:.2f}   CI [{ci['gamma'][0]:.2f}, {ci['gamma'][1]:.2f}]"
          f"   (0 = constant n_eff*, 1 = constant fraction of n)")
    print(f"\nOut-of-sample test (law + n_eff* fitted on the {s['h']} SMALLEST levels, scored on the rest):")
    print(f"   mean |ln beta* error|   constant-beta null: {s['err_const']:.3f}"
          f"   law, constant n_eff*: {s['err_law']:.3f}   law, n_eff* ~ n^gamma: {s['err_pow']:.3f}")
    ok = {}
    for tag, key, err in (("constant n_eff*", "err_gain", s["err_law"]), ("n_eff* ~ n^gamma", "err_gain_pow", s["err_pow"])):
        lo_, hi_ = ci[key]
        ok[tag] = lo_ > 0
        print(f"   gain over null, {tag}: {s['err_const'] - err:+.3f}   CI [{lo_:+.3f}, {hi_:+.3f}]"
              f"   -> {'SUPPORTED' if lo_ > 0 else 'NOT supported (do not quote predictions below)'}")
    for tag, key, ext in (("constant n_eff*", "beta", s["extrap"]), ("n_eff* ~ n^gamma", "betapow", s["extrap_pow"])):
        if not ok[tag]:
            continue
        for n in N_EXTRAP:
            c_ = ci[f"{key}@{n}"]
            print(f"Prediction beta*(n={n}) [{tag}] = {ext[n]:.1f}   CI [{c_[0]:.1f}, {c_[1]:.1f}]"
                  f"   (beyond measured n={a['ntr'].max():.0f}; falsifiable)")
    if not any(ok.values()):
        print("No scaling prediction beat the constant-beta null out-of-sample; "
              "report the n_eff law (above) and say beta* is flat over the measured range of n.")


def make_figure(res, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    modes = list(res)
    fig, ax = plt.subplots(len(modes), 3, figsize=(16, 4.6 * len(modes)), constrained_layout=True,
                           squeeze=False)
    for r, mode in enumerate(modes):
        s = res[mode][0]
        a = s["a"]
        cm = plt.cm.viridis(np.linspace(0, 1, len(a["ntr"])))
        for l in range(len(a["ntr"])):
            ax[r, 0].plot(BETA, a["neff"][l] / a["ntr"][l], "o-", color=cm[l], ms=3,
                          label=f"n={a['ntr'][l]:.0f}")
        la = s["law_all"]
        ax[r, 0].plot(BETA, np.exp(la["lnA"] - la["c"] * BETA), "k--", label=f"law c={la['c']:.2f}")
        ax[r, 0].set_yscale("log"); ax[r, 0].set_xlabel("beta"); ax[r, 0].set_ylabel("n_eff / n_train")
        ax[r, 0].set_title(f"[{mode}] n_eff/n_train vs beta"); ax[r, 0].legend(fontsize=6, ncol=2)

        n = a["ntr"]
        ax[r, 1].plot(n, s["b_acc"], "o", color="#1b9e77", label="empirical beta* (accuracy)")
        ax[r, 1].plot(n, s["b_cal"], "s", color="#d95f02", label="beta where cov95 = 0.95")
        grid = np.linspace(n.min(), max(N_EXTRAP) * 1.05, 100)
        ax[r, 1].plot(grid, beta_pred(grid, s["law_all"], s["nstar_all"]), "-", color="#1b9e77", alpha=0.6,
                      label="law, constant n_eff* (all levels)")
        ax[r, 1].plot(n[s["h"]:], s["pred_hi"], "k^", label="out-of-sample: constant n_eff*")
        ax[r, 1].plot(n[s["h"]:], s["pred_hi_pow"], "mv", label="out-of-sample: n_eff* ~ n^gamma")
        ax[r, 1].axvline(n.max(), color="grey", ls=":")
        ax[r, 1].set_xscale("log"); ax[r, 1].set_xlabel("n_train"); ax[r, 1].set_ylabel("beta")
        ax[r, 1].set_title(f"[{mode}] best beta vs n"); ax[r, 1].legend(fontsize=7)

        ax[r, 2].plot(n, s["n_star"], "o-", color="#1b9e77")
        ax[r, 2].axhline(s["nstar_all"], color="grey", ls="--")
        ax[r, 2].set_xscale("log"); ax[r, 2].set_xlabel("n_train"); ax[r, 2].set_ylabel("n_eff at accuracy optimum")
        ax[r, 2].set_title(f"[{mode}] is n_eff* constant in n?")
    fig.savefig(f"{out_dir}/fig6_scaling_law.png", dpi=160, bbox_inches="tight"); plt.close(fig)


def analyse(X, y, groups, Model, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            modes=("adaptive", "fixed"), reps=REPS, n_boot=N_BOOT, out_dir=OUT_DIR, seed=0):
    groups = np.asarray(groups)
    print(f"\nLayer 3 data: X={X.shape}, groups={len(set(groups))}, levels={FRACS}, reps={reps}")
    os.makedirs(out_dir, exist_ok=True)
    res = {}
    for mode in modes:
        print(f"\nCollecting subsampled LOEGO runs, length-scale mode = {mode} ...")
        T = collect(X, y, groups, Model, corr, floor_frac, mode, reps, seed)
        s = study(T, np.ones(T.shape[0]))
        ci = bootstrap(T, n_boot, seed)
        res[mode] = (s, ci)
        report(mode, s, ci)
        rows = []
        for l in range(len(s["a"]["ntr"])):
            for b, beta in enumerate(BETA):
                rows.append(dict(mode=mode, n_train=s["a"]["ntr"][l], beta=beta, n_eff=s["a"]["neff"][l, b],
                                 mse=s["a"]["mse"][l, b], cov68=s["a"]["cov68"][l, b],
                                 cov95=s["a"]["cov95"][l, b]))
        pd.DataFrame(rows).to_csv(f"{out_dir}/scaling_{mode}.csv", index=False)
    make_figure(res, out_dir)
    if len(modes) == 2:
        ca, cf = (res[m][0]["law_all"]["c"] for m in modes)
        print(f"\nNormalisation check: c(adaptive)={ca:.3f} vs c(fixed)={cf:.3f}. "
              "If they are close and the out-of-sample test still favours the law under 'fixed', "
              "the scaling is not an artefact of Layer 0's length-scale normalisation.")
    print(f"\nSaved tables + figure in ./{out_dir}/")
    return res
