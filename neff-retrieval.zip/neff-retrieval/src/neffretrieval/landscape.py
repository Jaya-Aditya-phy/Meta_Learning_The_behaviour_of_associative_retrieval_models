"""
Density / energy landscape of the retrieval model (maps only, no data points).

For a point xi in the model's feature space (standardised, correlation-masked, distances divided by
s = the typical nearest-neighbour distance):

    L(xi)  = log sum_i exp(-beta * d(xi, z_i) / s)    log-density: how crowded stored samples are near xi
    E(xi)  = - L(xi) / beta                            energy: the same map upside-down (valleys = samples)
    w_i    = softmax_i(-beta * d / s)                  voting weights
    mu(xi) = sum_i w_i y_i                             predicted target
    n_eff  = 1 / sum_i w_i^2                           effective number of voters

The space is high-dimensional, so each map is a flat 2-D SLICE through it: the plane of the two directions
of greatest variation (PC1, PC2). Grid points are mapped back into the full space and distances to every
stored sample are computed in ALL dimensions. This visualises the FITTED model; it makes no accuracy claim.

Run:  neffretrieval landscape --csv data.csv --target y --group batch
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import logsumexp, softmax

BETAS = (0.5, 2.0, 8.0)
BETA_NOTES = {0.5: "smooth: many samples vote", 2.0: "an accuracy-oriented setting", 8.0: "sharp: one sample dominates"}
BETA_FOCUS = 2.0
CORR_THRESHOLD = 0.4
RES = 170
OUT_DIR = "outputs/landscape"
plt.rcParams.update({"font.size": 14, "axes.titlesize": 15, "axes.labelsize": 14})

KEY = (
    "HOW TO READ THESE MAPS\n"
    "Each map is a flat slice through the high-dimensional feature space. Its axes are the two directions in which the stored samples "
    "differ most (PC1, PC2), in units of the typical distance between a sample and its nearest neighbour.\n"
    "Density  L = log \u03a3 exp(\u2212\u03b2 \u00b7 d / s):  how crowded stored samples are around a point  "
    "(d = distance to a stored sample, s = typical nearest-neighbour distance).      "
    "\u03b2 (sharpness): how fast a sample's influence fades with distance. Low \u03b2: many samples vote. High \u03b2: only the closest vote.\n"
    "Energy  E = \u2212L / \u03b2:  the same map turned upside-down, so valleys sit where stored samples are.      "
    "n_eff = 1 / \u03a3 w\u1d62\u00b2:  the effective number of samples contributing to a prediction (w\u1d62 = voting weights). "
    "Low n_eff = few voters, so the prediction and its uncertainty are less reliable."
)


def build_plane(m, y, pad_frac=0.12, res=RES):
    Z = m.Z_
    mu0 = Z.mean(axis=0)
    _, S, Vt = np.linalg.svd(Z - mu0, full_matrices=False)
    P = (Z - mu0) @ Vt[:2].T
    ev = (S ** 2 / np.sum(S ** 2))[:2]
    corr = [float(np.corrcoef(P[:, j], y)[0, 1]) for j in range(2)]
    pad = pad_frac * (P.max(axis=0) - P.min(axis=0))
    gx = np.linspace(P[:, 0].min() - pad[0], P[:, 0].max() + pad[0], res)
    gy = np.linspace(P[:, 1].min() - pad[1], P[:, 1].max() + pad[1], res)
    GX, GY = np.meshgrid(gx, gy)
    G = mu0 + np.c_[GX.ravel(), GY.ravel()] @ Vt[:2]
    D = m._dist(G, Z) / m.scale_
    s = m.scale_
    return dict(GX=GX / s, GY=GY / s, D=D, shape=GX.shape, ev=ev, corr=corr)


def fields(D, y, beta):
    s = -beta * D
    W = softmax(s, axis=1)
    return logsumexp(s, axis=1), W @ y, 1.0 / np.sum(W ** 2, axis=1)


def axis_labels(pl):
    return tuple(f"Axis {i + 1} (PC{i + 1}, {pl['ev'][i] * 100:.0f}% of variation)" for i in range(2))


def make_main_figure(pl, y, out_dir):
    GX, GY, shape = pl["GX"], pl["GY"], pl["shape"]
    xl, yl = axis_labels(pl)
    fig = plt.figure(figsize=(20, 15), layout="constrained")
    gs = fig.add_gridspec(3, 3, height_ratios=[1, 1, 0.30])
    ax = [[fig.add_subplot(gs[r, c]) for c in range(3)] for r in range(2)]
    for a, beta in zip(ax[0], BETAS):
        L, _, _ = fields(pl["D"], y, beta)
        Lr = (L - L.max()).reshape(shape)
        cs = a.contourf(GX, GY, Lr, levels=np.linspace(Lr.min(), 0, 24), cmap="viridis")
        a.set_title(f"Density of stored samples,  \u03b2 = {beta:g}\n({BETA_NOTES[beta]})")
        plt.colorbar(cs, ax=a, label="log-density (0 = most crowded point; bright = crowded)")
    L, mu, ne = fields(pl["D"], y, BETA_FOCUS)
    a = ax[1][0]
    cs = a.contourf(GX, GY, mu.reshape(shape), levels=24, cmap="coolwarm")
    a.set_title(f"Predicted target,  \u03b2 = {BETA_FOCUS:g}\n(what the model would answer at each point)")
    plt.colorbar(cs, ax=a, label="predicted target (red = high, blue = low)")
    a = ax[1][1]
    cs = a.contourf(GX, GY, np.log10(ne).reshape(shape), levels=24, cmap="cividis")
    cl = a.contour(GX, GY, ne.reshape(shape), levels=[3, 7, 15], colors="w", linewidths=[1.2, 2.6, 1.2],
                   linestyles=["dotted", "solid", "dashed"])
    a.clabel(cl, fmt={3: "n_eff = 3", 7: "n_eff = 7", 15: "n_eff = 15"}, fontsize=11)
    a.set_title(f"How many samples vote (n_eff),  \u03b2 = {BETA_FOCUS:g}\n(dark = few voters = least reliable)")
    plt.colorbar(cs, ax=a, label="log\u2081\u2080 n_eff (effective number of voting samples)")
    a = ax[1][2]
    Er = (-(L - L.max()) / BETA_FOCUS).reshape(shape)
    cs = a.contourf(GX, GY, Er, levels=24, cmap="viridis_r")
    a.contour(GX, GY, Er, levels=24, colors="k", linewidths=0.3, alpha=0.5)
    a.set_title(f"Energy  E = \u2212L/\u03b2,  \u03b2 = {BETA_FOCUS:g}\n(valleys, shown bright, are where stored samples sit)")
    plt.colorbar(cs, ax=a, label="energy above the deepest valley (lower = deeper)")
    for row in ax:
        for a in row:
            a.set_xlabel(xl, fontsize=12); a.set_ylabel(yl, fontsize=12)
    kx = fig.add_subplot(gs[2, :])
    kx.axis("off")
    rel = lambda r: "strongly" if abs(r) > 0.6 else "moderately" if abs(r) > 0.3 else "weakly"
    extra = (f"\nAxis 1 is {rel(pl['corr'][0])} related to the target (r = {pl['corr'][0]:+.2f}); "
             f"axis 2 is {rel(pl['corr'][1])} related (r = {pl['corr'][1]:+.2f}). Axis units: typical nearest-neighbour distance.")
    kx.text(0.0, 0.95, KEY + extra, va="top", ha="left", fontsize=13.5, wrap=True, linespacing=1.5,
            bbox=dict(boxstyle="round,pad=0.6", fc="#f5f5f5", ec="#999999"), transform=kx.transAxes)
    fig.suptitle("Landscape of the retrieval model: a 2-D slice through the feature space", fontsize=19)
    fig.savefig(f"{out_dir}/fig10_density_landscape.png", dpi=200, bbox_inches="tight")
    plt.close(fig)


def make_3d_figure(pl, y, out_dir, betas=(1.0, 4.0)):
    GX, GY, shape = pl["GX"], pl["GY"], pl["shape"]
    fig = plt.figure(figsize=(18, 8))
    notes = {1.0: "broad valley: many samples vote", 4.0: "sharper valleys: fewer samples vote"}
    for i, beta in enumerate(betas):
        L, _, _ = fields(pl["D"], y, beta)
        E = (-(L - L.max()) / beta).reshape(shape)
        a = fig.add_subplot(1, 2, i + 1, projection="3d")
        a.plot_surface(GX, GY, E, cmap="viridis_r", linewidth=0, antialiased=True, rstride=2, cstride=2)
        a.set_title(f"Energy surface,  \u03b2 = {beta:g}\n({notes.get(beta, '')})")
        a.set_xlabel("Axis 1 (PC1)", labelpad=10); a.set_ylabel("Axis 2 (PC2)", labelpad=10)
        a.set_zlabel("Energy E (lower = deeper valley)", labelpad=10)
        a.view_init(elev=36, azim=-62)
    fig.text(0.5, 0.02, "Axes: units of the typical nearest-neighbour distance.  E = \u2212L/\u03b2 with L = log \u03a3 exp(\u2212\u03b2 d / s).  "
             "Valleys are where stored samples sit.", ha="center", fontsize=12)
    fig.savefig(f"{out_dir}/fig11_energy_surface_3d.png", dpi=200, bbox_inches="tight")
    plt.close(fig)


def analyse(X, y_log, Model, corr=CORR_THRESHOLD, out_dir=OUT_DIR):
    os.makedirs(out_dir, exist_ok=True)
    m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X, y_log)
    pl = build_plane(m, y_log)
    print(f"Slice: PC1 {pl['ev'][0] * 100:.1f}% + PC2 {pl['ev'][1] * 100:.1f}% = {pl['ev'].sum() * 100:.1f}% of the variation "
          f"in the stored samples;  corr(PC1, y) = {pl['corr'][0]:+.2f}, corr(PC2, y) = {pl['corr'][1]:+.2f}")
    _, _, ne = fields(pl["D"], y_log, BETA_FOCUS)
    print(f"At beta={BETA_FOCUS:g}: n_eff over the plane {ne.min():.1f}-{ne.max():.1f} (median {np.median(ne):.1f}); "
          f"{np.mean(ne < 3) * 100:.0f}% of the plane has n_eff < 3")
    make_main_figure(pl, y_log, out_dir)
    make_3d_figure(pl, y_log, out_dir)
    print(f"Saved fig10_density_landscape.png and fig11_energy_surface_3d.png in ./{out_dir}/")
