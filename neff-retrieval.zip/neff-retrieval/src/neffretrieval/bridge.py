"""
LAYER 1 -- THE BRIDGE VARIABLE (effective sample size, n_eff)
==============================================================
Studies the *exact* Layer 0 model (AssociativeRetrieval) from the inside.

Layer 0 asks:  "Given a droplet's 40-D morphology, what is its concentration?"
Layer 1 asks:  "What is the retrieval doing inside when it answers, and can ONE
                number summarise that?"

        n_eff = 1 / sum_i p_i^2          p_i = Layer-0 retrieval weights

Claim tested: accuracy, calibration and predictive entropy are (approximately)
functions of n_eff, and n_eff is set by Layer 0's two internal controls:
        beta : sharpness (dimensionless, train-length-scale normalised)
        k    : how many stored droplets may vote

What changed vs the previous Layer 1 draft
  * Uses Layer 0's AssociativeRetrieval itself (same beta, same metric, same
    per-fold scaler / length scale / correlation filter) -> Layers 2-4 can reuse it.
  * Target default matches Layer 0 (no silent switch of concentration definition).
  * Predicts log10 concentration; metrics are all in that one space.
  * Uncertainty floor tied to the training label spread (was 1e-3, which made
    NLL / z^2 blow up whenever neighbours agreed).
  * Bridge test uses grouped CV (leave-one-k-out / leave-one-beta-out) instead of
    leave-one-config-out on a smooth grid, which leaks between neighbouring configs.

Run:
    neffretrieval bridge --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.special import logsumexp, softmax
from scipy.stats import norm
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

# ----------------------------------------------------------------------------
# CONFIG
# ----------------------------------------------------------------------------
# beta=0 is excluded on purpose: with all logits tied at 0, Layer 0's top-k rule
# (s >= kth) keeps EVERY point, so k would stop doing anything.
BETA_GRID = [0.25, 0.5, 1, 2, 4, 8, 16, 32]
K_GRID = [3, 5, 9, 16, 32, 64, 100]            # all < smallest LOEGO train size
CORR_THRESHOLD = 0.4                           # same as Layer 0; None disables
SIGMA_FLOOR_FRAC = 0.05                        # floor = frac * std(train log10 y)
OUT_DIR = "outputs/bridge"


# ----------------------------------------------------------------------------
# PART A -- quantities of a weight matrix (rows = queries)
# ----------------------------------------------------------------------------
def n_eff_from_weights(W):
    """Effective sample size 1 / sum p^2.  Range: 1 (one voter) .. k (equal votes)."""
    return 1.0 / np.sum(W ** 2, axis=1)


def shannon_entropy(W):
    """H = -sum p log p (nats). Always >= log(n_eff) (Renyi-2 <= Shannon)."""
    return -np.sum(W * np.log(np.maximum(W, 1e-300)), axis=1)


def n_eff_closed_form(logits):
    """n_eff = Z(1)^2 / Z(2) with Z(b) = sum exp(b * logit): depends on the
    similarities only through two log-sum-exp numbers."""
    return np.exp(2.0 * logsumexp(logits, axis=1) - logsumexp(2.0 * logits, axis=1))


def _selftest():
    rng = np.random.default_rng(0)
    s = rng.normal(size=(6, 25))
    p = softmax(s, axis=1)
    assert np.allclose(n_eff_from_weights(p), n_eff_closed_form(s))
    assert np.all(shannon_entropy(p) >= np.log(n_eff_from_weights(p)) - 1e-12)


# ----------------------------------------------------------------------------
# PART B -- LOEGO sweep using the Layer 0 model
# ----------------------------------------------------------------------------
def run_sweep(X, y_log, groups, Model, corr_threshold=CORR_THRESHOLD,
              floor_frac=SIGMA_FLOOR_FRAC):
    """One row per (config, held-out droplet). Model = Layer 0 AssociativeRetrieval."""
    chunks = []
    for fold, (tr, te) in enumerate(LeaveOneGroupOut().split(X, y_log, groups)):
        # everything data-dependent (scaler, medians, length scale, corr mask) is
        # fitted ONCE per fold on TRAIN rows only; beta / k only change retrieval.
        m = Model(beta=1.0, k=None, corr_threshold=corr_threshold).fit(X[tr], y_log[tr])
        floor = floor_frac * np.std(y_log[tr])
        for k in K_GRID:
            for beta in BETA_GRID:
                m.beta, m.k = beta, k
                mu, sd, W = m.predict(X[te])
                n = len(te)
                chunks.append(pd.DataFrame(dict(
                    fold=fold, group=groups[te], k=k, beta=beta,
                    y_true=y_log[te], y_hat=mu, sigma=np.maximum(sd, floor),
                    n_eff=n_eff_from_weights(W), H=shannon_entropy(W))))
    return pd.concat(chunks, ignore_index=True)


# ----------------------------------------------------------------------------
# PART C -- three diagnostics per config: accuracy, calibration, entropy
# ----------------------------------------------------------------------------
def summarise_configs(q):
    q = q.copy()
    q["err"] = q["y_hat"] - q["y_true"]
    q["z"] = q["err"] / q["sigma"]
    q["sq"] = q["err"] ** 2
    q["ae"] = q["err"].abs()
    q["z2"] = q["z"] ** 2
    q["nll"] = -norm.logpdf(q["err"], scale=q["sigma"])
    q["in68"] = (q["z"].abs() <= 1.0).astype(float)
    q["in95"] = (q["z"].abs() <= 1.96).astype(float)
    q["ln_neff"] = np.log(q["n_eff"])
    cfg = q.groupby(["k", "beta"]).agg(
        n_eff=("n_eff", "mean"), log_n_eff=("ln_neff", "mean"), H=("H", "mean"),
        mse=("sq", "mean"), mae=("ae", "mean"), nll=("nll", "mean"),
        mean_z2=("z2", "mean"), cov68=("in68", "mean"), cov95=("in95", "mean"),
        var_y=("y_true", lambda s: s.var(ddof=0))).reset_index()
    cfg["r2"] = 1.0 - cfg["mse"] / cfg["var_y"]                 # accuracy
    return cfg.drop(columns="var_y")


# ----------------------------------------------------------------------------
# PART D -- bridge test: does ONE variable explain as much as TWO?
# ----------------------------------------------------------------------------
def grouped_r2(F, target, groups, degree=2, alpha=1e-2):
    """R^2 of a small polynomial ridge, evaluated on whole held-out groups."""
    pred = np.empty(len(target), float)
    for tr, te in LeaveOneGroupOut().split(F, target, groups):
        mdl = make_pipeline(StandardScaler(), PolynomialFeatures(degree, include_bias=False),
                            Ridge(alpha=alpha)).fit(F[tr], target[tr])
        pred[te] = mdl.predict(F[te])
    return 1.0 - np.sum((target - pred) ** 2) / np.sum((target - target.mean()) ** 2)


def bridge_test(cfg):
    """
    Predict each diagnostic from
        log n_eff | log k | log beta | (log k, log beta)
    on whole held-out k values (and, separately, whole held-out beta values),
    so neighbouring configs cannot leak. The 2-knob model has MORE parameters, so
    if log n_eff alone matches it the claim is conservative, not flattered.
    """
    lk, lb, ln = np.log(cfg["k"]).values, np.log(cfg["beta"]).values, cfg["log_n_eff"].values
    feats = {"log n_eff": ln[:, None], "log k": lk[:, None], "log beta": lb[:, None],
             "log k + log beta": np.c_[lk, lb]}
    diagnostics = ["r2", "mae", "nll", "mean_z2", "cov68", "cov95", "H"]
    out = {}
    for split_name, g in (("leave-one-k-out", cfg["k"].values),
                          ("leave-one-beta-out", cfg["beta"].values)):
        tab = pd.DataFrame(index=diagnostics, columns=list(feats), dtype=float)
        for d in diagnostics:
            for name, F in feats.items():
                tab.loc[d, name] = grouped_r2(F, cfg[d].values, g)
        out[split_name] = tab
    return out


def variance_law(cfg):
    """MSE = b + c / n_eff   (b: bias floor, c/n_eff: averaging noise)."""
    x = (1.0 / cfg["n_eff"].values)[:, None]
    lr = LinearRegression().fit(x, cfg["mse"].values)
    return lr.intercept_, lr.coef_[0], lr.score(x, cfg["mse"].values)


# ----------------------------------------------------------------------------
# PART E -- figures
# ----------------------------------------------------------------------------
def make_figures(cfg, per_query, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    piv = cfg.pivot(index="beta", columns="k", values="n_eff")           # Fig 1
    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(np.log10(piv.values), origin="lower", aspect="auto", cmap="viridis")
    ax.set_xticks(range(len(piv.columns)), piv.columns)
    ax.set_yticks(range(len(piv.index)), [f"{b:g}" for b in piv.index])
    ax.set_xlabel("k (voters allowed)"); ax.set_ylabel("beta (sharpness)")
    ax.set_title("Mean n_eff across the two controls")
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            ax.text(j, i, f"{piv.values[i, j]:.1f}", ha="center", va="center", fontsize=6, color="w")
    plt.colorbar(im, label="log10 n_eff"); fig.tight_layout()
    fig.savefig(f"{out_dir}/fig1_neff_heatmap.png", dpi=160); plt.close(fig)

    panels = [("r2", "accuracy: R2 (log10 conc)"), ("mae", "accuracy: MAE"),   # Fig 2
              ("nll", "calibration: Gaussian NLL"), ("cov68", "calibration: 68% coverage"),
              ("mean_z2", "calibration: mean z^2 (ideal 1)"), ("H", "predictive entropy H")]
    fig, axes = plt.subplots(2, 3, figsize=(13, 8), constrained_layout=True)
    for ax, (col, title) in zip(axes.ravel(), panels):
        sc = ax.scatter(cfg["n_eff"], cfg[col], c=np.log10(cfg["beta"]), s=14 + 3 * np.sqrt(cfg["k"]),
                        cmap="plasma", alpha=0.8, edgecolor="k", linewidth=0.3)
        ax.set_xscale("log"); ax.set_xlabel("n_eff"); ax.set_title(title, fontsize=10)
        if col in ("nll", "mean_z2"):
            ax.set_yscale("symlog", linthresh=1.0)
        if col == "cov68": ax.axhline(0.68, ls="--", c="grey")
        if col == "mean_z2": ax.axhline(1.0, ls="--", c="grey")
    fig.colorbar(sc, ax=axes, label="log10 beta  (marker size ~ sqrt k)", shrink=0.8)
    fig.suptitle("Every (k, beta) config is a dot. If n_eff is the bridge, dots form ONE curve.")
    fig.savefig(f"{out_dir}/fig2_collapse.png", dpi=160, bbox_inches="tight"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 5))                                  # Fig 3
    ax.scatter(np.log(per_query["n_eff"]), per_query["H"], s=3, alpha=0.2)
    m = np.log(per_query["n_eff"].max())
    ax.plot([0, m], [0, m], "k--", label="H = log n_eff (lower bound)")
    ax.set_xlabel("log n_eff"); ax.set_ylabel("Shannon entropy H (nats)")
    ax.set_title("Entropy vs n_eff"); ax.legend()
    fig.tight_layout(); fig.savefig(f"{out_dir}/fig3_entropy_vs_neff.png", dpi=160); plt.close(fig)

    b, c, r2 = variance_law(cfg)                                              # Fig 4
    fig, ax = plt.subplots(figsize=(5.5, 5))
    ax.scatter(1 / cfg["n_eff"], cfg["mse"], c=np.log10(cfg["beta"]), cmap="plasma", s=25)
    xs = np.linspace(0, (1 / cfg["n_eff"]).max(), 50)
    ax.plot(xs, b + c * xs, "k--", label=f"MSE = {b:.3f} + {c:.3f}/n_eff  (R2={r2:.2f})")
    ax.set_xlabel("1 / n_eff"); ax.set_ylabel("MSE (log10 conc)"); ax.legend()
    fig.tight_layout(); fig.savefig(f"{out_dir}/fig4_variance_law.png", dpi=160); plt.close(fig)


# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------
def analyse(X, y_log, groups, Model, corr_threshold=CORR_THRESHOLD,
            floor_frac=SIGMA_FLOOR_FRAC, out_dir=OUT_DIR):
    _selftest()
    print(f"\nLayer 1 data: X={X.shape}, groups={len(set(groups))}, "
          f"log10 conc range [{y_log.min():.2f}, {y_log.max():.2f}]")
    print("Running LOEGO sweep over (k, beta) grid ...")
    per_query = run_sweep(X, y_log, groups, Model, corr_threshold, floor_frac)
    cfg = summarise_configs(per_query)

    os.makedirs(out_dir, exist_ok=True)
    per_query.to_csv(f"{out_dir}/per_query.csv", index=False)
    cfg.to_csv(f"{out_dir}/per_config.csv", index=False)

    best = cfg.loc[cfg["r2"].idxmax()]
    print(f"\nBest-accuracy config   : k={best['k']:.0f}, beta={best['beta']:g}, "
          f"n_eff={best['n_eff']:.2f}, R2={best['r2']:.3f}, MAE={best['mae']:.3f}")
    bn = cfg.loc[cfg["nll"].idxmin()]
    print(f"Best-calibration config: k={bn['k']:.0f}, beta={bn['beta']:g}, "
          f"n_eff={bn['n_eff']:.2f}, NLL={bn['nll']:.3f}, cov68={bn['cov68']:.2f}, cov95={bn['cov95']:.2f}")

    print("\n=== BRIDGE TEST (grouped-CV R^2 of predicting each diagnostic) ===")
    for name, tab in bridge_test(cfg).items():
        print(f"\n[{name}]"); print(tab.round(3).to_string())
        tab.to_csv(f"{out_dir}/bridge_test_{name}.csv")

    b, c, r2 = variance_law(cfg)
    print(f"\nVariance law: MSE = {b:.4f} + {c:.4f} / n_eff   (R^2 = {r2:.3f})")
    print(f"corr(log n_eff, H) over all queries = "
          f"{np.corrcoef(np.log(per_query['n_eff']), per_query['H'])[0, 1]:.4f}")
    make_figures(cfg, per_query, out_dir)
    print(f"\nSaved tables + figures in ./{out_dir}/")
    return per_query, cfg
