"""
LAYER 4 -- PHYSICAL GROUNDING: does the model's internal behaviour track the physics?
======================================================================================
Layers 1-3 found that the retrieval model is organised by n_eff, which depends on how crowded or
isolated a droplet's morphology is among the stored droplets. Layer 4 asks whether that behaviour is
explained by PHYSICAL variables of the experiment, or is just an artefact of the data.

Per held-out droplet (nested leave-one-batch-out; model fitted on other batches only) we measure
    n_eff_acc    effective voters at the accuracy setting          (k=9,  beta=2 by default)
    n_eff_cal    effective voters at the calibration setting       (k=100, beta=1 by default)
    c_local      local decay rate: -slope of ln n_eff vs beta, per droplet  (the Layer 3 constant, per query)
    isolation    distance to the nearest training droplet / typical NN distance  (how sparse its region is)
    abs_err_cal  |prediction - truth| at the calibration setting
    zabs_acc     |error| / sigma at the accuracy setting          (overconfidence; 1 is ideal)

Physical variables: glycerol_pct, the (glycerol-adjusted) log10 concentration, particle type parsed from
the batch name (e.g. gly0_ps01 -> glycerol 0, 'ps'), plus ANY numeric columns in an optional CSV you
supply (Peclet, Marangoni, contact angle, ... keyed by droplet_id or by group). Droplets in a batch are
replicates, so everything is aggregated to the BATCH level (the unit that matters) before testing.

Tests (batch level): Spearman rho with a batch-bootstrap 95% CI and a permutation p-value, Holm-corrected
across all pairs; Kruskal-Wallis for categorical variables. Every variable's dynamic range is printed, and
the MINIMUM DETECTABLE |rho| (80% power) is reported, so a null result says how large an effect it could
actually rule out.

Run:
    neffretrieval grounding --csv data.csv --target y --group batch
    neffretrieval grounding --csv data.csv --target y --group batch
"""
import argparse
import importlib
import os
import re
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import kruskal, norm, rankdata
from sklearn.model_selection import LeaveOneGroupOut

from . import bridge as L1

CORR_THRESHOLD, SIGMA_FLOOR_FRAC = L1.CORR_THRESHOLD, L1.SIGMA_FLOOR_FRAC
C_BETAS = [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8]       # moderate-beta range where the n_eff law holds
BEHAVIOURS = ["n_eff_acc", "n_eff_cal", "c_local", "isolation", "abs_err_cal", "zabs_acc"]
N_PERM, N_BOOT = 5000, 1500
OUT_DIR = "outputs/grounding"


# ----------------------------------------------------------------------------
# per-droplet behaviour under nested leave-one-batch-out
# ----------------------------------------------------------------------------
def query_embedding(m, Xq):
    Xq = np.where(np.isnan(np.asarray(Xq, float)), m.med_, Xq)
    return m._embed(m.scaler_.transform(Xq))


def local_decay(m, Xq):
    """per-query c: -slope of ln n_eff vs beta over the moderate range (needs >= 3 points with n_eff >= 2)."""
    m.k = None
    NE = []
    for b in C_BETAS:
        m.beta = b
        NE.append(L1.n_eff_from_weights(m.weights(Xq)))
    NE = np.array(NE)                                    # (B, nq)
    betas = np.array(C_BETAS)
    c = np.full(NE.shape[1], np.nan)
    for q in range(NE.shape[1]):
        ok = NE[:, q] >= 2.0
        if ok.sum() >= 3:
            c[q] = -np.polyfit(betas[ok], np.log(NE[ok, q]), 1)[0]
    return c


def behaviours(X, y, groups, Model, corr, floor_frac, acc, cal):
    n = len(y)
    out = {b: np.full(n, np.nan) for b in BEHAVIOURS}
    for tr, te in LeaveOneGroupOut().split(X, y, groups):
        m = Model(beta=1.0, k=None, corr_threshold=corr).fit(X[tr], y[tr])
        floor = floor_frac * np.std(y[tr])
        for tag, (k, b) in (("acc", acc), ("cal", cal)):
            m.k, m.beta = k, b
            mu, sd, W = m.predict(X[te])
            sd = np.maximum(sd, floor)
            out[f"n_eff_{tag}"][te] = L1.n_eff_from_weights(W)
            if tag == "cal":
                out["abs_err_cal"][te] = np.abs(mu - y[te])
            else:
                out["zabs_acc"][te] = np.abs(mu - y[te]) / sd
        out["c_local"][te] = local_decay(m, X[te])
        Zq = query_embedding(m, X[te])
        out["isolation"][te] = (m._dist(Zq, m.Z_) / m.scale_).min(axis=1)
    return pd.DataFrame(out)


# ----------------------------------------------------------------------------
# statistics (batch level)
# ----------------------------------------------------------------------------
def spearman_fast(x, y):
    rx, ry = rankdata(x), rankdata(y)
    rx, ry = (rx - rx.mean()) / (rx.std() + 1e-12), (ry - ry.mean()) / (ry.std() + 1e-12)
    return float(np.mean(rx * ry))


def perm_p(x, y, rho, rng, n_perm=N_PERM):
    rx, ry = rankdata(x), rankdata(y)
    rx, ry = (rx - rx.mean()) / (rx.std() + 1e-12), (ry - ry.mean()) / (ry.std() + 1e-12)
    perms = np.array([np.mean(rx[rng.permutation(len(rx))] * ry) for _ in range(n_perm)])
    return float((np.sum(np.abs(perms) >= abs(rho) - 1e-12) + 1) / (n_perm + 1))


def boot_ci(x, y, rng, n_boot=N_BOOT):
    n = len(x)
    vals = []
    for _ in range(n_boot):
        ii = rng.integers(0, n, n)
        if np.ptp(x[ii]) == 0 or np.ptp(y[ii]) == 0:
            continue
        vals.append(spearman_fast(x[ii], y[ii]))
    return np.percentile(vals, [2.5, 97.5]) if vals else (np.nan, np.nan)


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (len(p) - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def min_detectable_rho(n, alpha=0.05, power=0.80):
    z = (norm.ppf(1 - alpha / 2) + norm.ppf(power)) / np.sqrt(max(n - 3, 1))
    return float(np.tanh(z))


# ----------------------------------------------------------------------------
# physics table
# ----------------------------------------------------------------------------
def particle_type(group):
    m = re.match(r"^gly\d+_([A-Za-z]+)", str(group))
    return m.group(1).lower() if m else "unknown"


def build_physics(df, y, groups, extra=None):
    ph = pd.DataFrame({"group": groups, "glycerol_pct": df["glycerol_pct"].values,
                       "log10_conc": y, "particle": [particle_type(g) for g in groups]})
    if extra is not None:
        for c in extra.columns:
            ph[c] = extra[c].values
    return ph


def build_physics_generic(frame, group_col, physics_cols, category_col=None, target=None, target_name="target"):
    """Generic physics table: numeric columns of `frame` (one value per row), an optional categorical column,
    and optionally the target itself (so data-coverage effects can be inspected)."""
    ph = pd.DataFrame({"group": frame[group_col].values})
    ph["particle"] = frame[category_col].astype(str).values if category_col else "all"
    for c in physics_cols:
        ph[c] = pd.to_numeric(frame[c], errors="coerce").values
    if target is not None:
        ph[target_name] = np.asarray(target, float)
    return ph


def dynamic_range(ph, groups, numeric):
    rows = []
    for c in numeric:
        v = ph[c].astype(float)
        bm = ph.groupby("group")[c].mean()
        pos = v[v > 0]
        rows.append(dict(variable=c, min=v.min(), max=v.max(),
                         max_over_min=(pos.max() / pos.min()) if len(pos) == len(v) and pos.min() > 0 else np.nan,
                         distinct_batch_values=int(bm.round(8).nunique()), n_batches=len(bm),
                         share_of_variance_between_batches=float(min(1.0, bm.var(ddof=0) / (v.var(ddof=0) + 1e-12)))))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------
# main analysis
# ----------------------------------------------------------------------------
def analyse(X, y, groups, Model, physics, corr=CORR_THRESHOLD, floor_frac=SIGMA_FLOOR_FRAC,
            acc=(9, 2.0), cal=(100, 1.0), out_dir=OUT_DIR, seed=0):
    groups = np.asarray(groups)
    os.makedirs(out_dir, exist_ok=True)
    rng = np.random.default_rng(seed)
    print(f"\nLayer 4 data: X={X.shape}, batches={len(set(groups))}; accuracy setting k,beta={acc}; "
          f"calibration setting k,beta={cal}")
    beh = behaviours(X, y, groups, Model, corr, floor_frac, acc, cal)
    numeric = [c for c in physics.columns if c not in ("group", "particle") and
               pd.api.types.is_numeric_dtype(physics[c])]
    cats = ["particle"] + [c for c in numeric if physics[c].nunique() <= 6]

    print("\n=== DYNAMIC RANGE OF THE PHYSICAL VARIABLES (a null result is only as informative as this) ===")
    dr = dynamic_range(physics, groups, numeric)
    print(dr.round(3).to_string(index=False))
    print("particle types:", physics.groupby("particle")["group"].nunique().to_dict(), "(batches each)")

    bt = pd.concat([physics.assign(**{c: beh[c].values for c in BEHAVIOURS})], axis=1)
    agg = {c: "mean" for c in numeric + BEHAVIOURS}
    agg["particle"] = "first"
    batch = bt.groupby("group").agg(agg).reset_index()
    n_b = len(batch)
    mde = min_detectable_rho(n_b)
    print(f"\n{n_b} batches. Minimum detectable |Spearman rho| at 80% power, alpha=0.05: {mde:.2f}  "
          f"(smaller true effects cannot be ruled in or out)")
    batch.to_csv(f"{out_dir}/batch_table.csv", index=False)

    rows = []
    for b in BEHAVIOURS:
        for p in numeric:
            x, yy = batch[p].values.astype(float), batch[b].values.astype(float)
            ok = np.isfinite(x) & np.isfinite(yy)
            if ok.sum() < 8 or np.ptp(x[ok]) == 0:
                continue
            rho = spearman_fast(x[ok], yy[ok])
            lo, hi = boot_ci(x[ok], yy[ok], rng)
            rows.append(dict(behaviour=b, physics=p, rho=rho, ci_lo=lo, ci_hi=hi,
                             p_perm=perm_p(x[ok], yy[ok], rho, rng), n=int(ok.sum())))
    res = pd.DataFrame(rows)
    res["p_holm"] = holm(res["p_perm"].values)

    def verdict(r):
        if r.p_holm < 0.05:
            return "ASSOCIATION"
        if max(abs(r.ci_lo), abs(r.ci_hi)) < mde:
            return "no effect as large as the minimum detectable"
        return "inconclusive (CI wider than the detectable effect)"
    res["verdict"] = res.apply(verdict, axis=1)
    res.to_csv(f"{out_dir}/numeric_tests.csv", index=False)
    pd.set_option("display.width", 220, "display.max_colwidth", 60)
    print("\n=== NUMERIC PHYSICS vs MODEL BEHAVIOUR (batch level, Spearman; Holm over all pairs) ===")
    print(res.round(3).to_string(index=False))

    crow = []
    for c in cats:
        for b in BEHAVIOURS:
            g = [v[b].dropna().values for _, v in batch.groupby(c) if v[b].notna().sum() >= 2]
            if len(g) >= 2:
                H, p = kruskal(*g)
                crow.append(dict(behaviour=b, factor=c, levels=len(g), H=H, p=p,
                                 epsilon_sq=H / max(n_b - 1, 1)))
    cat = pd.DataFrame(crow)
    if len(cat):
        cat["p_holm"] = holm(cat["p"].values)
        cat.to_csv(f"{out_dir}/categorical_tests.csv", index=False)
        print("\n=== CATEGORICAL FACTORS (Kruskal-Wallis over batches; epsilon^2 = effect size) ===")
        print(cat.round(3).to_string(index=False))

    nd = int((res.p_holm < 0.05).sum())
    print(f"\nSUMMARY: {nd} of {len(res)} numeric pairs survive Holm correction"
          + (f" ({', '.join(res[res.p_holm < 0.05].apply(lambda r: r.behaviour + '~' + r.physics, axis=1))})." if nd else "."))
    make_figure(res, batch, numeric, mde, out_dir)
    print(f"Saved tables + figure in ./{out_dir}/")
    return res, cat, batch


def make_figure(res, batch, numeric, mde, out_dir):
    if res.empty:
        return
    M = res.pivot(index="behaviour", columns="physics", values="rho").reindex(index=BEHAVIOURS)
    P = res.pivot(index="behaviour", columns="physics", values="p_holm").reindex(index=BEHAVIOURS)
    fig, ax = plt.subplots(1, 2, figsize=(16, 6.2), constrained_layout=True,
                           gridspec_kw={"width_ratios": [1.15, 1]})
    im = ax[0].imshow(M.values.astype(float), cmap="RdBu_r", vmin=-1, vmax=1, aspect="auto")
    ax[0].set_xticks(range(M.shape[1]), M.columns, rotation=30, ha="right")
    ax[0].set_yticks(range(M.shape[0]), M.index)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v, p = M.values[i, j], P.values[i, j]
            if np.isfinite(v):
                ax[0].text(j, i, f"{v:+.2f}" + ("*" if p < 0.05 else ""), ha="center", va="center", fontsize=11)
    plt.colorbar(im, ax=ax[0], label="Spearman rho (batch level)")
    ax[0].set_title(f"Model behaviour vs physical variables  (* = survives Holm; minimum detectable |rho| = {mde:.2f})")
    top = res.iloc[res["rho"].abs().argmax()]
    ax[1].scatter(batch[top.physics], batch[top.behaviour], s=40, edgecolor="k")
    ax[1].set_xlabel(f"{top.physics} (batch mean)"); ax[1].set_ylabel(f"{top.behaviour} (batch mean)")
    ax[1].set_title(f"Strongest pair: rho = {top.rho:+.2f}  95% CI [{top.ci_lo:+.2f}, {top.ci_hi:+.2f}]\n"
                    f"Holm-adjusted p = {top.p_holm:.3f}")
    fig.savefig(f"{out_dir}/fig12_physical_grounding.png", dpi=170, bbox_inches="tight")
    plt.close(fig)


