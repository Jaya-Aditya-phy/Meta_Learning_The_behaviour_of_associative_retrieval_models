"""Quickstart: fit the retrieval model, look at n_eff, and score it with leave-one-batch-out.

Run:  python examples/quickstart.py
"""
import numpy as np

from neffretrieval import AssociativeRetrieval, loego, make_synthetic
from neffretrieval.bridge import n_eff_from_weights

X, y, batch = make_synthetic()

# 1. one fitted model: predictions, a spread-based uncertainty, and the retrieval weights
m = AssociativeRetrieval(beta=2.0, k=9, corr_threshold=0.4).fit(X[:100], y[:100])
mu, sigma, W = m.predict(X[100:])
print(f"effective voters per query (n_eff): mean {n_eff_from_weights(W).mean():.1f}")

# 2. leave-one-batch-out accuracy at two settings: sharper vs smoother retrieval
for beta, k in [(2.0, 9), (1.0, 100)]:
    out = loego(X, y, batch, beta=beta, k=k, corr_threshold=0.4)
    print(f"beta={beta:<4} k={k:<4} R2={out['r2']:.3f}  mean n_eff={out['n_eff'].mean():.1f}")
