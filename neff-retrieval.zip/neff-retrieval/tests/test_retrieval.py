import numpy as np

from neffretrieval import AssociativeRetrieval, loego
from neffretrieval.bridge import n_eff_closed_form, n_eff_from_weights, shannon_entropy


def test_weights_are_a_distribution(small):
    X, y, _ = small
    m = AssociativeRetrieval(beta=2.0, k=9).fit(X[:40], y[:40])
    W = m.weights(X[40:])
    assert np.allclose(W.sum(axis=1), 1.0)
    assert (W >= 0).all()
    assert ((W > 0).sum(axis=1) <= 9).all()  # top-k truncation keeps at most k voters


def test_neff_bounds_and_limits(small):
    X, y, _ = small
    m = AssociativeRetrieval(beta=1e-6, k=7).fit(X[:40], y[:40])
    assert np.allclose(n_eff_from_weights(m.weights(X[40:])), 7, atol=1e-3)  # equal votes -> n_eff = k
    m.beta, m.k = 1e3, None
    ne = n_eff_from_weights(m.weights(X[40:]))  # very sharp: essentially one voter per query
    assert ne.min() >= 1.0 - 1e-9 and np.median(ne) < 1.01 and ne.max() < 2.5


def test_neff_decreases_with_beta(small):
    X, y, _ = small
    m = AssociativeRetrieval(k=None).fit(X[:40], y[:40])
    means = []
    for beta in (0.25, 1, 4, 16):
        m.beta = beta
        means.append(n_eff_from_weights(m.weights(X[40:])).mean())
    assert all(a > b for a, b in zip(means, means[1:]))


def test_closed_form_matches_direct():
    rng = np.random.default_rng(0)
    logits = rng.normal(size=(6, 25))
    p = np.exp(logits - logits.max(axis=1, keepdims=True))
    p /= p.sum(axis=1, keepdims=True)
    assert np.allclose(n_eff_closed_form(logits), 1.0 / (p ** 2).sum(axis=1))
    # the order-2 Renyi entropy never exceeds the Shannon entropy
    assert (shannon_entropy(p) >= np.log(n_eff_from_weights(p)) - 1e-12).all()


def test_no_label_leakage_across_groups(small):
    """Changing the held-out batch's labels must not change its predictions."""
    X, y, g = small
    te = g == g[0]
    base = AssociativeRetrieval(beta=2.0, k=9).fit(X[~te], y[~te]).predict(X[te])[0]
    y2 = y.copy()
    y2[te] = y2[te] + 100.0
    after = AssociativeRetrieval(beta=2.0, k=9).fit(X[~te], y2[~te]).predict(X[te])[0]
    assert np.array_equal(base, after)


def test_loego_runs(small):
    X, y, g = small
    out = loego(X, y, g, beta=2.0, k=9)
    assert len(out["y_pred"]) == len(y) and np.isfinite(out["r2"])
