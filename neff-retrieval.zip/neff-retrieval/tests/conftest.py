import pytest

from neffretrieval import make_synthetic


@pytest.fixture(scope="module")
def small():
    """A small synthetic problem: 60 samples, 12 batches (fast enough for CI)."""
    X, y, g = make_synthetic(n=60, n_features=20, n_groups=12, seed=3)
    return X, y, g
