import numpy as np
import pandas as pd

from neffretrieval import AssociativeRetrieval as M
from neffretrieval import bridge, grounding, neff_policy, nested, recalibration


def test_sweep_has_no_leakage(small):
    """y_hat of a held-out batch must not depend on that batch's own labels (checked through run_sweep)."""
    X, y, g = small
    a = bridge.run_sweep(X, y, g, M)
    y2 = y.copy()
    y2[g == g[0]] += 50.0
    b = bridge.run_sweep(X, y2, g, M)
    ra = np.sort(a[a.group == g[0]].y_hat.to_numpy())
    rb = np.sort(b[b.group == g[0]].y_hat.to_numpy())
    assert np.allclose(ra, rb)


def test_bridge_summary_columns(small):
    X, y, g = small
    cfg = bridge.summarise_configs(bridge.run_sweep(X, y, g, M))
    assert {"n_eff", "r2", "cov95", "H", "nll"} <= set(cfg.columns)
    assert len(cfg) == len(bridge.K_GRID) * len(bridge.BETA_GRID)


def test_nested_policies_run(small):
    X, y, g = small
    pred, grid, gmean, sel = nested.nested_cv(X, y, g, M, inner_splits=3)
    res = nested.summarise(y, g, pred, grid, gmean, sel)
    assert len(res) == 2 + len(nested.POLICIES)
    assert np.isfinite(res.r2).all()


def test_corrections_are_identity_for_perfect_predictions():
    y = np.linspace(-2, -1, 40)
    c = recalibration.fit_corrections(y, y.copy(), np.full(40, 0.1))
    assert abs(c["slope"] - 1) < 1e-6 and abs(c["icpt"]) < 1e-6


def test_sigma_factor_matches_rms_z():
    rng = np.random.default_rng(1)
    y = rng.normal(size=500)
    mu = y + rng.normal(scale=0.3, size=500)
    c = recalibration.fit_corrections(y, mu, np.full(500, 0.1))
    z = (mu - y) / 0.1
    assert abs(c["s_raw"] - min(5.0, np.sqrt(np.mean(z ** 2)))) < 1e-9


def test_target_neff_is_hit(small):
    X, y, g = small
    m = M(beta=1.0, k=None, corr_threshold=0.4).fit(X, y)
    curve = neff_policy.beta_curve(m, g)
    assert (np.diff(curve) <= 1e-9).all()  # n_eff is non-increasing in beta
    t = float(np.clip(5, curve[-1] + 0.5, curve[0] - 0.5))
    b = neff_policy.beta_for_target(curve, t)
    D = m._dist(m.Z_, m.Z_) / m.scale_
    mask = g[:, None] == g[None, :]
    assert abs(neff_policy._mean_neff(D, mask, b) - t) < 0.5


def test_statistics_helpers():
    assert abs(grounding.min_detectable_rho(32) - 0.48) < 0.01
    p = np.array([0.01, 0.04, 0.03])
    adj = grounding.holm(p)
    assert (adj >= p).all() and (adj <= 1).all()
    x = np.arange(20.0)
    assert abs(grounding.spearman_fast(x, x) - 1) < 1e-9
    assert abs(grounding.spearman_fast(x, -x) + 1) < 1e-9


def test_grounding_generic_table(small, tmp_path):
    X, y, g = small
    frame = pd.DataFrame({"batch": g, "pe": np.exp(np.random.default_rng(0).normal(size=len(g)))})
    ph = grounding.build_physics_generic(frame, "batch", ["pe"], target=y, target_name="y")
    res, cat, batch = grounding.analyse(X, y, g, M, ph, acc=(9, 2.0), cal=(20, 1.0), out_dir=str(tmp_path))
    assert {"rho", "p_holm", "verdict"} <= set(res.columns)
